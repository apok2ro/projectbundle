<?php

namespace Moz\ProjectBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MozProjectBundle extends Bundle
{
}
