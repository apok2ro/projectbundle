<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Location
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\LocationRepository")
 */
class Location
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Country")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $country;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Region")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $region;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Territory")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $Territory;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\District")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $district;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text")
     */
    private $name;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\Localisation", mappedBy="location")
     *
     */
    private $projects;

    /**
     * @var boolean
     *
     * @ORM\Column(name="valid", type="boolean")
     */
    private $valid;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }



    public function getFullname()
    {
        $name='';
        if($this->getCountry()){
            $name.= "[".$this->getCountry()->getName()."]";
            if($this->getRegion() && $this->getRegion()->getId() != 1){
                $name.= "[".$this->getRegion()->getName()."]";

                if($this->getTerritory() && $this->getTerritory()->getId() != 1){
                    $name.= "[".$this->getTerritory()->getName()."]";

                    if($this->getDistrict() && $this->getDistrict()->getId() != 1){
                        $name.= "[".$this->getDistrict()->getName()."]";
                    }
                }
            }
        }

        return $name;
    }
    

    /**
     * Set country
     *
     * @param \Moz\ProjectBundle\Entity\Country $country
     * @return Location
     */
    public function setCountry(\Moz\ProjectBundle\Entity\Country $country = null)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return \Moz\ProjectBundle\Entity\Country 
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Set region
     *
     * @param \Moz\ProjectBundle\Entity\Region $region
     * @return Location
     */
    public function setRegion(\Moz\ProjectBundle\Entity\Region $region = null)
    {
        $this->region = $region;

        return $this;
    }

    /**
     * Get region
     *
     * @return \Moz\ProjectBundle\Entity\Region 
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * Set Territory
     *
     * @param \Moz\ProjectBundle\Entity\Territory $Territory
     * @return Location
     */
    public function setTerritory(\Moz\ProjectBundle\Entity\Territory $Territory = null)
    {
        $this->Territory = $Territory;

        return $this;
    }

    /**
     * Get Territory
     *
     * @return \Moz\ProjectBundle\Entity\Territory 
     */
    public function getTerritory()
    {
        return $this->Territory;
    }

    /**
     * Set district
     *
     * @param \Moz\ProjectBundle\Entity\District $district
     * @return Location
     */
    public function setDistrict(\Moz\ProjectBundle\Entity\District $district = null)
    {
        $this->district = $district;

        return $this;
    }

    /**
     * Get district
     *
     * @return \Moz\ProjectBundle\Entity\District 
     */
    public function getDistrict()
    {
        return $this->district;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Location
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->projects = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add projects
     *
     * @param \Moz\ProjectBundle\Entity\Localisation $projects
     * @return Location
     */
    public function addProject(\Moz\ProjectBundle\Entity\Localisation $projects)
    {
        $projects->setLocation($this);
        $this->projects[] = $projects;

        return $this;
    }

    /**
     * Remove projects
     *
     * @param \Moz\ProjectBundle\Entity\Localisation $projects
     */
    public function removeProject(\Moz\ProjectBundle\Entity\Localisation $projects)
    {
        $this->projects->removeElement($projects);
    }

    /**
     * Get projects
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getProjects()
    {
        return $this->projects;
    }

    /**
     * Set valid
     *
     * @param boolean $valid
     * @return Location
     */
    public function setValid($valid)
    {
        $this->valid = $valid;

        return $this;
    }

    /**
     * Get valid
     *
     * @return boolean 
     */
    public function getValid()
    {
        return $this->valid;
    }
}
