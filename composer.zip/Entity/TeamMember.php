<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * TeamMember
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\TeamMemberRepository")
 */
class TeamMember
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var boolean
     *
     * @ORM\Column(name="readPermission", type="boolean", nullable=true)
     */
    private $readPermission;


    /**
     * @var boolean
     *
     * @ORM\Column(name="writePermission", type="boolean", nullable=true)
     */
    private $writePermission;


    /**
     * @var boolean
     *
     * @ORM\Column(name="deletePermission", type="boolean", nullable=true)
     */
    private $deletePermission;


    /**
     * @ORM\ManyToOne(targetEntity="Webkul\UVDesk\CoreFrameworkBundle\Entity\User")
     * @ORM\JoinColumn(nullable = true)
     */
    private $user;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\Moz\AdminBundle\Entity\Workspace", inversedBy="members")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $team;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\UserRole")
     * @ORM\JoinColumn(nullable = true)
     */
    private $role;


    /**
     * @var boolean
     *
     * @ORM\Column(name="uploadDoc", type="boolean", nullable=true)
     */
    private $uploadDoc;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set readPermission
     *
     * @param boolean $readPermission
     * @return TeamMember
     */
    public function setReadPermission($readPermission)
    {
        $this->readPermission = $readPermission;

        return $this;
    }

    /**
     * Get readPermission
     *
     * @return boolean 
     */
    public function getReadPermission()
    {
        return $this->readPermission;
    }

    /**
     * Set writePermission
     *
     * @param boolean $writePermission
     * @return TeamMember
     */
    public function setWritePermission($writePermission)
    {
        $this->writePermission = $writePermission;

        return $this;
    }

    /**
     * Get writePermission
     *
     * @return boolean 
     */
    public function getWritePermission()
    {
        return $this->writePermission;
    }

    /**
     * Set deletePermission
     *
     * @param boolean $deletePermission
     * @return TeamMember
     */
    public function setDeletePermission($deletePermission)
    {
        $this->deletePermission = $deletePermission;

        return $this;
    }

    /**
     * Get deletePermission
     *
     * @return boolean 
     */
    public function getDeletePermission()
    {
        return $this->deletePermission;
    }

    /**
     * Set uploadDoc
     *
     * @param boolean $uploadDoc
     * @return TeamMember
     */
    public function setUploadDoc($uploadDoc)
    {
        $this->uploadDoc = $uploadDoc;

        return $this;
    }

    /**
     * Get uploadDoc
     *
     * @return boolean 
     */
    public function getUploadDoc()
    {
        return $this->uploadDoc;
    }

    /**
     * Set user
     *
     * @param \Webkul\UVDesk\CoreFrameworkBundle\Entity\User $user
     * @return TeamMember
     */
    public function setUser(\Webkul\UVDesk\CoreFrameworkBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \Webkul\UVDesk\CoreFrameworkBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set team
     *
     * @param \Moz\Moz\AdminBundle\Entity\Workspace $team
     * @return TeamMember
     */
    public function setTeam(\Moz\Moz\AdminBundle\Entity\Workspace $team = null)
    {
        $this->team = $team;

        return $this;
    }

    /**
     * Get team
     *
     * @return \Moz\Moz\AdminBundle\Entity\Workspace 
     */
    public function getTeam()
    {
        return $this->team;
    }

    /**
     * Set role
     *
     * @param \Moz\ProjectBundle\Entity\UserRole $role
     * @return TeamMember
     */
    public function setRole(\Moz\ProjectBundle\Entity\UserRole $role = null)
    {
        $this->role = $role;

        return $this;
    }

    /**
     * Get role
     *
     * @return \Moz\ProjectBundle\Entity\UserRole 
     */
    public function getRole()
    {
        return $this->role;
    }
}
