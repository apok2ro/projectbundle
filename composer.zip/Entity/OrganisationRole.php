<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * OrganisationRole
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\OrganisationRoleRepository")
 */
class OrganisationRole
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Role")
     */
    private $role;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project",cascade={"persist"})
     */
    private $project;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     */
    private $organisation;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set role
     *
     * @param \Moz\ProjectBundle\Entity\Role $role
     * @return OrganisationRole
     */
    public function setRole(\Moz\ProjectBundle\Entity\Role $role = null)
    {
        $this->role = $role;

        return $this;
    }

    /**
     * Get role
     *
     * @return \Moz\ProjectBundle\Entity\Role 
     */
    public function getRole()
    {
        return $this->role;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return OrganisationRole
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set organisation
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $organisation
     * @return OrganisationRole
     */
    public function setOrganisation(\Moz\ProjectBundle\Entity\Organisation $organisation = null)
    {
        $this->organisation = $organisation;

        return $this;
    }

    /**
     * Get organisation
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getOrganisation()
    {
        return $this->organisation;
    }
}
