<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * FundingBase
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\FundingBaseRepository")
 */
class FundingBase
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $organisation;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $project;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $typeOfAssistance;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $financingInstrument;


    /**
     * @var string
     *
     * @ORM\Column(name="transaction", type="text")
     */
    private $transaction;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\FundingDetail", mappedBy="funding",cascade={"persist"})
     */
    private $commitments;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\FundingDetail", mappedBy="funding", cascade={"persist"})
     */
    private $dibursements;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\FundingDetail", mappedBy="funding", cascade={"persist"})
     */
    private $expanditures;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set transaction
     *
     * @param string $transaction
     * @return FundingBase
     */
    public function setTransaction($transaction)
    {
        $this->transaction = $transaction;

        return $this;
    }

    /**
     * Get transaction
     *
     * @return string 
     */
    public function getTransaction()
    {
        return $this->transaction;
    }

    /**
     * Set organisation
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $organisation
     * @return FundingBase
     */
    public function setOrganisation(\Moz\ProjectBundle\Entity\Organisation $organisation = null)
    {
        $this->organisation = $organisation;

        return $this;
    }

    /**
     * Get organisation
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getOrganisation()
    {
        return $this->organisation;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return FundingBase
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set typeOfAssistance
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $typeOfAssistance
     * @return FundingBase
     */
    public function setTypeOfAssistance(\Moz\ProjectBundle\Entity\CategoryValues $typeOfAssistance = null)
    {
        $this->typeOfAssistance = $typeOfAssistance;

        return $this;
    }

    /**
     * Get typeOfAssistance
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getTypeOfAssistance()
    {
        return $this->typeOfAssistance;
    }

    /**
     * Set financingInstrument
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $financingInstrument
     * @return FundingBase
     */
    public function setFinancingInstrument(\Moz\ProjectBundle\Entity\CategoryValues $financingInstrument = null)
    {
        $this->financingInstrument = $financingInstrument;

        return $this;
    }

    /**
     * Get financingInstrument
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getFinancingInstrument()
    {
        return $this->financingInstrument;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->commitments = new \Doctrine\Common\Collections\ArrayCollection();
        $this->dibursements = new \Doctrine\Common\Collections\ArrayCollection();
        $this->expanditures = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add commitments
     *
     * @param \Moz\ProjectBundle\Entity\FundingDetail $commitments
     * @return FundingBase
     */
    public function addCommitment(\Moz\ProjectBundle\Entity\FundingDetail $commitments)
    {
        $commitments->setFunding($this);
        $this->commitments[] = $commitments;

        return $this;
    }

    /**
     * Remove commitments
     *
     * @param \Moz\ProjectBundle\Entity\FundingDetail $commitments
     */
    public function removeCommitment(\Moz\ProjectBundle\Entity\FundingDetail $commitments)
    {
        $this->commitments->removeElement($commitments);
    }

    /**
     * Get commitments
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getCommitments()
    {
        return $this->commitments;
    }

    /**
     * Add dibursements
     *
     * @param \Moz\ProjectBundle\Entity\FundingDetail $dibursements
     * @return FundingBase
     */
    public function addDibursement(\Moz\ProjectBundle\Entity\FundingDetail $dibursements)
    {
        $dibursements->setFunding($this);
        $this->dibursements[] = $dibursements;

        return $this;
    }

    /**
     * Remove dibursements
     *
     * @param \Moz\ProjectBundle\Entity\FundingDetail $dibursements
     */
    public function removeDibursement(\Moz\ProjectBundle\Entity\FundingDetail $dibursements)
    {
        $this->dibursements->removeElement($dibursements);
    }

    /**
     * Get dibursements
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getDibursements()
    {
        return $this->dibursements;
    }

    /**
     * Add expanditures
     *
     * @param \Moz\ProjectBundle\Entity\FundingDetail $expanditures
     * @return FundingBase
     */
    public function addExpanditure(\Moz\ProjectBundle\Entity\FundingDetail $expanditures)
    {
        $expanditures->setFunding($this);
        $this->expanditures[] = $expanditures;

        return $this;
    }

    /**
     * Remove expanditures
     *
     * @param \Moz\ProjectBundle\Entity\FundingDetail $expanditures
     */
    public function removeExpanditure(\Moz\ProjectBundle\Entity\FundingDetail $expanditures)
    {
        $this->expanditures->removeElement($expanditures);
    }

    /**
     * Get expanditures
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getExpanditures()
    {
        return $this->expanditures;
    }
}
