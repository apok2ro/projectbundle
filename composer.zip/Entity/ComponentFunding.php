<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ComponentFunding
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ComponentFundingRepository")
 */
class ComponentFunding
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="transactionDate", type="text", nullable=true)
     */
    private $transactionDate;

    /**
     * @var float
     *
     * @ORM\Column(name="transactionAmount", type="float", nullable=true)
     */
    private $transactionAmount;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="reportingDate", type="text", nullable=true)
     */
    private $reportingDate;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $transactionType;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $adjustmentType;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Currency")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $currency;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Component")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $component;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set transactionDate
     *
     * @param \DateTime $transactionDate
     * @return ComponentFunding
     */
    public function setTransactionDate($transactionDate)
    {
        $this->transactionDate = $transactionDate;

        return $this;
    }

    /**
     * Get transactionDate
     *
     * @return \DateTime 
     */
    public function getTransactionDate()
    {
        return $this->transactionDate;
    }

    /**
     * Set transactionAmount
     *
     * @param float $transactionAmount
     * @return ComponentFunding
     */
    public function setTransactionAmount($transactionAmount)
    {
        $this->transactionAmount = $transactionAmount;

        return $this;
    }

    /**
     * Get transactionAmount
     *
     * @return float 
     */
    public function getTransactionAmount()
    {
        return $this->transactionAmount;
    }

    /**
     * Set reportingDate
     *
     * @param \DateTime $reportingDate
     * @return ComponentFunding
     */
    public function setReportingDate($reportingDate)
    {
        $this->reportingDate = $reportingDate;

        return $this;
    }

    /**
     * Get reportingDate
     *
     * @return \DateTime 
     */
    public function getReportingDate()
    {
        return $this->reportingDate;
    }

    /**
     * Set transactionType
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $transactionType
     * @return ComponentFunding
     */
    public function setTransactionType(\Moz\ProjectBundle\Entity\CategoryValues $transactionType = null)
    {
        $this->transactionType = $transactionType;

        return $this;
    }

    /**
     * Get transactionType
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getTransactionType()
    {
        return $this->transactionType;
    }

    /**
     * Set adjustmentType
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $adjustmentType
     * @return ComponentFunding
     */
    public function setAdjustmentType(\Moz\ProjectBundle\Entity\CategoryValues $adjustmentType = null)
    {
        $this->adjustmentType = $adjustmentType;

        return $this;
    }

    /**
     * Get adjustmentType
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getAdjustmentType()
    {
        return $this->adjustmentType;
    }

    
    /**
     * Set component
     *
     * @param \Moz\ProjectBundle\Entity\Component $component
     * @return ComponentFunding
     */
    public function setComponent(\Moz\ProjectBundle\Entity\Component $component = null)
    {
        $this->component = $component;

        return $this;
    }

    /**
     * Get component
     *
     * @return \Moz\ProjectBundle\Entity\Component 
     */
    public function getComponent()
    {
        return $this->component;
    }

    /**
     * Set currency
     *
     * @param \Moz\ProjectBundle\Entity\Currency $currency
     * @return ComponentFunding
     */
    public function setCurrency(\Moz\ProjectBundle\Entity\Currency $currency = null)
    {
        $this->currency = $currency;

        return $this;
    }

    /**
     * Get currency
     *
     * @return \Moz\ProjectBundle\Entity\Currency 
     */
    public function getCurrency()
    {
        return $this->currency;
    }
}
