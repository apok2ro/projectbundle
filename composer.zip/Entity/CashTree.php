<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CashTree
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\CashTreeRepository")
 */
class CashTree
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $project;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $transactionType;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $adjustmentType;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Currency")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $currency;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="transactionDate", type="text", nullable=true)
     *
     */
    private $transactionDate;

    /**
     * @var float
     *
     * @ORM\Column(name="transactionAmount", type="float", nullable=true)
     */
    private $transactionAmount;

    /**
     * @var float
     *
     * @ORM\Column(name="eng_eff", type="float", nullable=true)
     */
    private $engEff;

    /**
     * @var float
     *
     * @ORM\Column(name="dib_eff", type="float", nullable=true)
     */
    private $dibEff;

    /**
     * @var float
     *
     * @ORM\Column(name="exp_eff", type="float", nullable=true)
     */
    private $expEff;

    /**
     * @var float
     *
     * @ORM\Column(name="eng_prev", type="float", nullable=true)
     */
    private $engPrev;

    /**
     * @var float
     *
     * @ORM\Column(name="dib_prev", type="float", nullable=true)
     */
    private $dibPrev;

    /**
     * @var float
     *
     * @ORM\Column(name="exp_prev", type="float", nullable=true)
     */
    private $expPrev;






    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set transactionDate
     *
     * @param string $transactionDate
     * @return CashTree
     */
    public function setTransactionDate($transactionDate)
    {
        $this->transactionDate = $transactionDate;

        return $this;
    }

    /**
     * Get transactionDate
     *
     * @return string 
     */
    public function getTransactionDate()
    {
        return $this->transactionDate;
    }

    /**
     * Set transactionAmount
     *
     * @param float $transactionAmount
     * @return CashTree
     */
    public function setTransactionAmount($transactionAmount)
    {
        $this->transactionAmount = $transactionAmount;

        return $this;
    }

    /**
     * Get transactionAmount
     *
     * @return float 
     */
    public function getTransactionAmount()
    {
        return $this->transactionAmount;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return CashTree
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set transactionType
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $transactionType
     * @return CashTree
     */
    public function setTransactionType(\Moz\ProjectBundle\Entity\CategoryValues $transactionType = null)
    {
        $this->transactionType = $transactionType;

        return $this;
    }

    /**
     * Get transactionType
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getTransactionType()
    {
        return $this->transactionType;
    }

    /**
     * Set adjustmentType
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $adjustmentType
     * @return CashTree
     */
    public function setAdjustmentType(\Moz\ProjectBundle\Entity\CategoryValues $adjustmentType = null)
    {
        $this->adjustmentType = $adjustmentType;

        return $this;
    }

    /**
     * Get adjustmentType
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getAdjustmentType()
    {
        return $this->adjustmentType;
    }

    /**
     * Set currency
     *
     * @param \Moz\ProjectBundle\Entity\Currency $currency
     * @return CashTree
     */
    public function setCurrency(\Moz\ProjectBundle\Entity\Currency $currency = null)
    {
        $this->currency = $currency;

        return $this;
    }

    /**
     * Get currency
     *
     * @return \Moz\ProjectBundle\Entity\Currency 
     */
    public function getCurrency()
    {
        return $this->currency;
    }

    /**
     * Set engEff
     *
     * @param float $engEff
     * @return CashTree
     */
    public function setEngEff($engEff)
    {
        $this->engEff = $engEff;

        return $this;
    }

    /**
     * Get engEff
     *
     * @return float 
     */
    public function getEngEff()
    {
        return $this->engEff;
    }

    /**
     * Set dibEff
     *
     * @param float $dibEff
     * @return CashTree
     */
    public function setDibEff($dibEff)
    {
        $this->dibEff = $dibEff;

        return $this;
    }

    /**
     * Get dibEff
     *
     * @return float 
     */
    public function getDibEff()
    {
        return $this->dibEff;
    }

    /**
     * Set expEff
     *
     * @param float $expEff
     * @return CashTree
     */
    public function setExpEff($expEff)
    {
        $this->expEff = $expEff;

        return $this;
    }

    /**
     * Get expEff
     *
     * @return float 
     */
    public function getExpEff()
    {
        return $this->expEff;
    }

    /**
     * Set engPrev
     *
     * @param float $engPrev
     * @return CashTree
     */
    public function setEngPrev($engPrev)
    {
        $this->engPrev = $engPrev;

        return $this;
    }

    /**
     * Get engPrev
     *
     * @return float 
     */
    public function getEngPrev()
    {
        return $this->engPrev;
    }

    /**
     * Set dibPrev
     *
     * @param float $dibPrev
     * @return CashTree
     */
    public function setDibPrev($dibPrev)
    {
        $this->dibPrev = $dibPrev;

        return $this;
    }

    /**
     * Get dibPrev
     *
     * @return float 
     */
    public function getDibPrev()
    {
        return $this->dibPrev;
    }

    /**
     * Set expPrev
     *
     * @param float $expPrev
     * @return CashTree
     */
    public function setExpPrev($expPrev)
    {
        $this->expPrev = $expPrev;

        return $this;
    }

    /**
     * Get expPrev
     *
     * @return float 
     */
    public function getExpPrev()
    {
        return $this->expPrev;
    }
}
