<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Funding
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\FundingRepository")
 */
class Funding
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="funding", type="text")
     */
    private $funding;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\Project", mappedBy="funding")
     */
    private $projects;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set funding
     *
     * @param string $funding
     * @return Funding
     */
    public function setFunding($funding)
    {
        $this->funding = $funding;

        return $this;
    }

    /**
     * Get funding
     *
     * @return string 
     */
    public function getFunding()
    {
        return $this->funding;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->projects = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add projects
     *
     * @param \Moz\ProjectBundle\Entity\Project $projects
     * @return Funding
     */
    public function addProject(\Moz\ProjectBundle\Entity\Project $projects)
    {
        $projects->setFunding($this);
        $this->projects[] = $projects;

        return $this;
    }

    /**
     * Remove projects
     *
     * @param \Moz\ProjectBundle\Entity\Project $projects
     */
    public function removeProject(\Moz\ProjectBundle\Entity\Project $projects)
    {
        $this->projects->removeElement($projects);
    }

    /**
     * Get projects
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getProjects()
    {
        return $this->projects;
    }
}
