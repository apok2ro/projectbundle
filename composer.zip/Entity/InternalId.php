<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * InternalId
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\InternalIdRepository")
 */
class InternalId
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="value", type="text")
     */
    private $value;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $organisation;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\OrganisationGroup")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $group;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project", inversedBy="keys")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $project;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set value
     *
     * @param string $value
     * @return InternalId
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return string 
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set organisation
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $organisation
     * @return InternalId
     */
    public function setOrganisation(\Moz\ProjectBundle\Entity\Organisation $organisation = null)
    {
        $this->organisation = $organisation;

        return $this;
    }

    /**
     * Get organisation
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getOrganisation()
    {
        return $this->organisation;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return InternalId
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set group
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationGroup $group
     * @return InternalId
     */
    public function setGroup(\Moz\ProjectBundle\Entity\OrganisationGroup $group = null)
    {
        $this->group = $group;

        return $this;
    }

    /**
     * Get group
     *
     * @return \Moz\ProjectBundle\Entity\OrganisationGroup 
     */
    public function getGroup()
    {
        return $this->group;
    }
}
