<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CategoryClass
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\CategoryClassRepository")
 */
class CategoryClass
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text")
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="keyname", type="string", length=255)
     */
    private $keyname;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text")
     */
    private $description;

    /**
     * @var boolean
     *
     * @ORM\Column(name="isMultiselect", type="boolean")
     */
    private $isMultiselect;

    /**
     * @var boolean
     *
     * @ORM\Column(name="isOrdered", type="boolean")
     */
    private $isOrdered;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return CategoryClass
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set keyname
     *
     * @param string $keyname
     * @return CategoryClass
     */
    public function setKeyname($keyname)
    {
        $this->keyname = $keyname;

        return $this;
    }

    /**
     * Get keyname
     *
     * @return string 
     */
    public function getKeyname()
    {
        return $this->keyname;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return CategoryClass
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set isMultiselect
     *
     * @param boolean $isMultiselect
     * @return CategoryClass
     */
    public function setIsMultiselect($isMultiselect)
    {
        $this->isMultiselect = $isMultiselect;

        return $this;
    }

    /**
     * Get isMultiselect
     *
     * @return boolean 
     */
    public function getIsMultiselect()
    {
        return $this->isMultiselect;
    }

    /**
     * Set isOrdered
     *
     * @param boolean $isOrdered
     * @return CategoryClass
     */
    public function setIsOrdered($isOrdered)
    {
        $this->isOrdered = $isOrdered;

        return $this;
    }

    /**
     * Get isOrdered
     *
     * @return boolean 
     */
    public function getIsOrdered()
    {
        return $this->isOrdered;
    }
}
