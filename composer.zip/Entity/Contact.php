<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Contact
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ContactRepository")
 */
class Contact
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="lastname", type="string", length=255, nullable=true)
     */
    private $lastname;

    /**
     * @var string
     *
     * @ORM\Column(name="organisationname", type="string", length=255, nullable=true)
     */
    private $organisationname;

    /**
     * @var string
     *
     * @ORM\Column(name="function", type="string", length=255, nullable=true)
     */
    private $function;

    /**
     * @var string
     *
     * @ORM\Column(name="officeaddress", type="string", length=255, nullable=true)
     */
    private $officeaddress;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     */
    private $title;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ContactProperty", mappedBy="contact",cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $mails;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ContactProperty", mappedBy="contact",cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $faxs;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ContactProperty", mappedBy="contact",cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $phones;




    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Contact
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set lastname
     *
     * @param string $lastname
     * @return Contact
     */
    public function setLastname($lastname)
    {
        $this->lastname = $lastname;

        return $this;
    }

    /**
     * Get lastname
     *
     * @return string 
     */
    public function getLastname()
    {
        return $this->lastname;
    }

    /**
     * Set organisationname
     *
     * @param string $organisationname
     * @return Contact
     */
    public function setOrganisationname($organisationname)
    {
        $this->organisationname = $organisationname;

        return $this;
    }

    /**
     * Get organisationname
     *
     * @return string 
     */
    public function getOrganisationname()
    {
        return $this->organisationname;
    }

    /**
     * Set function
     *
     * @param string $function
     * @return Contact
     */
    public function setFunction($function)
    {
        $this->function = $function;

        return $this;
    }

    /**
     * Get function
     *
     * @return string 
     */
    public function getFunction()
    {
        return $this->function;
    }

    /**
     * Set officeaddress
     *
     * @param string $officeaddress
     * @return Contact
     */
    public function setOfficeaddress($officeaddress)
    {
        $this->officeaddress = $officeaddress;

        return $this;
    }

    /**
     * Get officeaddress
     *
     * @return string 
     */
    public function getOfficeaddress()
    {
        return $this->officeaddress;
    }


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->mails = new \Doctrine\Common\Collections\ArrayCollection();
        $this->faxs = new \Doctrine\Common\Collections\ArrayCollection();
        $this->phones = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Set title
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $title
     * @return Contact
     */
    public function setTitle(\Moz\ProjectBundle\Entity\CategoryValues $title = null)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Add mails
     *
     * @param \Moz\ProjectBundle\Entity\ContactProperty $mails
     * @return Contact
     */
    public function addMail(\Moz\ProjectBundle\Entity\ContactProperty $mails)
    {
        $mails->setContact($this);
        $this->mails[] = $mails;

        return $this;
    }

    /**
     * Remove mails
     *
     * @param \Moz\ProjectBundle\Entity\ContactProperty $mails
     */
    public function removeMail(\Moz\ProjectBundle\Entity\ContactProperty $mails)
    {
        $this->mails->removeElement($mails);
    }

    /**
     * Get mails
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMails()
    {
        return $this->mails;
    }

    /**
     * Add faxs
     *
     * @param \Moz\ProjectBundle\Entity\ContactProperty $faxs
     * @return Contact
     */
    public function addFax(\Moz\ProjectBundle\Entity\ContactProperty $faxs)
    {
        $faxs->setContact($this);
        $this->faxs[] = $faxs;

        return $this;
    }

    /**
     * Remove faxs
     *
     * @param \Moz\ProjectBundle\Entity\ContactProperty $faxs
     */
    public function removeFax(\Moz\ProjectBundle\Entity\ContactProperty $faxs)
    {
        $this->faxs->removeElement($faxs);
    }

    /**
     * Get faxs
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getFaxs()
    {
        return $this->faxs;
    }

    /**
     * Add phones
     *
     * @param \Moz\ProjectBundle\Entity\ContactProperty $phones
     * @return Contact
     */
    public function addPhone(\Moz\ProjectBundle\Entity\ContactProperty $phones)
    {
        $phones->setContact($this);
        $this->phones[] = $phones;

        return $this;
    }

    /**
     * Remove phones
     *
     * @param \Moz\ProjectBundle\Entity\ContactProperty $phones
     */
    public function removePhone(\Moz\ProjectBundle\Entity\ContactProperty $phones)
    {
        $this->phones->removeElement($phones);
    }

    /**
     * Get phones
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPhones()
    {
        return $this->phones;
    }
}
