<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * UserRole
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\UserRoleRepository")
 */
class UserRole
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="role", type="string", length=255)
     */
    private $role;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text")
     */
    private $description;

    /**
     * @var boolean
     *
     * @ORM\Column(name="readPermission", type="boolean")
     */
    private $readPermission;

    /**
     * @var boolean
     *
     * @ORM\Column(name="writePermission", type="boolean")
     */
    private $writePermission;

    /**
     * @var boolean
     *
     * @ORM\Column(name="deletePermission", type="boolean")
     */
    private $deletePermission;

    /**
     * @var boolean
     *
     * @ORM\Column(name="headPermission", type="boolean")
     */
    private $headPermission;

    /**
     * @var boolean
     *
     * @ORM\Column(name="approvePermission", type="boolean")
     */
    private $approvePermission;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set role
     *
     * @param string $role
     * @return UserRole
     */
    public function setRole($role)
    {
        $this->role = $role;

        return $this;
    }

    /**
     * Get role
     *
     * @return string 
     */
    public function getRole()
    {
        return $this->role;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return UserRole
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set readPermission
     *
     * @param boolean $readPermission
     * @return UserRole
     */
    public function setReadPermission($readPermission)
    {
        $this->readPermission = $readPermission;

        return $this;
    }

    /**
     * Get readPermission
     *
     * @return boolean 
     */
    public function getReadPermission()
    {
        return $this->readPermission;
    }

    /**
     * Set writePermission
     *
     * @param boolean $writePermission
     * @return UserRole
     */
    public function setWritePermission($writePermission)
    {
        $this->writePermission = $writePermission;

        return $this;
    }

    /**
     * Get writePermission
     *
     * @return boolean 
     */
    public function getWritePermission()
    {
        return $this->writePermission;
    }

    /**
     * Set deletePermission
     *
     * @param boolean $deletePermission
     * @return UserRole
     */
    public function setDeletePermission($deletePermission)
    {
        $this->deletePermission = $deletePermission;

        return $this;
    }

    /**
     * Get deletePermission
     *
     * @return boolean 
     */
    public function getDeletePermission()
    {
        return $this->deletePermission;
    }

    /**
     * Set headPermission
     *
     * @param boolean $headPermission
     * @return UserRole
     */
    public function setHeadPermission($headPermission)
    {
        $this->headPermission = $headPermission;

        return $this;
    }

    /**
     * Get headPermission
     *
     * @return boolean 
     */
    public function getHeadPermission()
    {
        return $this->headPermission;
    }

    /**
     * Set approvePermission
     *
     * @param boolean $approvePermission
     * @return UserRole
     */
    public function setApprovePermission($approvePermission)
    {
        $this->approvePermission = $approvePermission;

        return $this;
    }

    /**
     * Get approvePermission
     *
     * @return boolean 
     */
    public function getApprovePermission()
    {
        return $this->approvePermission;
    }
}
