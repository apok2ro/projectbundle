<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Component
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ComponentRepository")
 */
class Component
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255, nullable=true)
     */
    private $code;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="text", nullable=true)
     */
    private $date;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\ComponentType")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $type;


    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ComponentFunding", mappedBy="component", cascade={"persist"})
     */
    private $commitments;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ComponentFunding", mappedBy="component", cascade={"persist"})
     */
    private $dibursements;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ComponentFunding", mappedBy="component", cascade={"persist"})
     */
    private $expanditures;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Component
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Component
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return Component
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string 
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return Component
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getDate()
    {
        return $this->date;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->commitments = new \Doctrine\Common\Collections\ArrayCollection();
        $this->dibursements = new \Doctrine\Common\Collections\ArrayCollection();
        $this->expanditures = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Set type
     *
     * @param \Moz\ProjectBundle\Entity\ComponentType $type
     * @return Component
     */
    public function setType(\Moz\ProjectBundle\Entity\ComponentType $type = null)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return \Moz\ProjectBundle\Entity\ComponentType 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Add commitments
     *
     * @param \Moz\ProjectBundle\Entity\ComponentFunding $commitments
     * @return Component
     */
    public function addCommitment(\Moz\ProjectBundle\Entity\ComponentFunding $commitments)
    {
        $commitments->setComponent($this);
        $this->commitments[] = $commitments;

        return $this;
    }

    /**
     * Remove commitments
     *
     * @param \Moz\ProjectBundle\Entity\ComponentFunding $commitments
     */
    public function removeCommitment(\Moz\ProjectBundle\Entity\ComponentFunding $commitments)
    {
        $this->commitments->removeElement($commitments);
    }

    /**
     * Get commitments
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getCommitments()
    {
        return $this->commitments;
    }

    /**
     * Add dibursements
     *
     * @param \Moz\ProjectBundle\Entity\ComponentFunding $dibursements
     * @return Component
     */
    public function addDibursement(\Moz\ProjectBundle\Entity\ComponentFunding $dibursements)
    {
        $dibursements->setComponent($this);
        $this->dibursements[] = $dibursements;

        return $this;
    }

    /**
     * Remove dibursements
     *
     * @param \Moz\ProjectBundle\Entity\ComponentFunding $dibursements
     */
    public function removeDibursement(\Moz\ProjectBundle\Entity\ComponentFunding $dibursements)
    {
        $this->dibursements->removeElement($dibursements);
    }

    /**
     * Get dibursements
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getDibursements()
    {
        return $this->dibursements;
    }

    /**
     * Add expanditures
     *
     * @param \Moz\ProjectBundle\Entity\ComponentFunding $expanditures
     * @return Component
     */
    public function addExpanditure(\Moz\ProjectBundle\Entity\ComponentFunding $expanditures)
    {
        $expanditures->setComponent($this);
        $this->expanditures[] = $expanditures;

        return $this;
    }

    /**
     * Remove expanditures
     *
     * @param \Moz\ProjectBundle\Entity\ComponentFunding $expanditures
     */
    public function removeExpanditure(\Moz\ProjectBundle\Entity\ComponentFunding $expanditures)
    {
        $this->expanditures->removeElement($expanditures);
    }

    /**
     * Get expanditures
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getExpanditures()
    {
        return $this->expanditures;
    }
}
