<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * OrganisationGroup
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\OrganisationGroupRepository")
 */
class OrganisationGroup
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text", nullable=true)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255, nullable=true)
     */
    private $code;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\OrganisationType", inversedBy="groups")
     */
    private $type;


    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\Organisation", mappedBy="group")
     */
    private $organisations;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return OrganisationGroup
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return OrganisationGroup
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string 
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set type
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationType $type
     * @return OrganisationGroup
     */
    public function setType(\Moz\ProjectBundle\Entity\OrganisationType $type = null)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return \Moz\ProjectBundle\Entity\OrganisationType 
     */
    public function getType()
    {
        return $this->type;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->organisations = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add organisations
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $organisations
     * @return OrganisationGroup
     */
    public function addOrganisation(\Moz\ProjectBundle\Entity\Organisation $organisations)
    {
        $organisations->setGroup($this);
        $this->organisations[] = $organisations;

        return $this;
    }

    /**
     * Remove organisations
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $organisations
     */
    public function removeOrganisation(\Moz\ProjectBundle\Entity\Organisation $organisations)
    {
        $this->organisations->removeElement($organisations);
    }

    /**
     * Get organisations
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getOrganisations()
    {
        return $this->organisations;
    }
}
