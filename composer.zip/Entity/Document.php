<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Document
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\DocumentRepository")
 */
class Document
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="note", type="string", length=255, nullable=true)
     */
    private $note;

    /**
     * @var string
     *
     * @ORM\Column(name="uri", type="text", nullable=true)
     */
    private $uri;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $type;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\Moz\AdminBundle\Entity\MediaScheme", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $media;

    /**
     * @var boolean
     *
     * @ORM\Column(name="islink", type="boolean", nullable=true)
     */
    private $isLink;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Document
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Document
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set note
     *
     * @param string $note
     * @return Document
     */
    public function setNote($note)
    {
        $this->note = $note;

        return $this;
    }

    /**
     * Get note
     *
     * @return string 
     */
    public function getNote()
    {
        return $this->note;
    }

    /**
     * Set uri
     *
     * @param string $uri
     * @return Document
     */
    public function setUri($uri)
    {
        $this->uri = $uri;

        return $this;
    }

    /**
     * Get uri
     *
     * @return string 
     */
    public function getUri()
    {
        return $this->uri;
    }

    /**
     * Set isLink
     *
     * @param boolean $isLink
     * @return Document
     */
    public function setIsLink($isLink)
    {
        $this->isLink = $isLink;

        return $this;
    }

    /**
     * Get isLink
     *
     * @return boolean 
     */
    public function getIsLink()
    {
        return $this->isLink;
    }

    /**
     * Set type
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $type
     * @return Document
     */
    public function setType(\Moz\ProjectBundle\Entity\CategoryValues $type = null)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set media
     *
     * @param \Moz\Moz\AdminBundle\Entity\MediaScheme $media
     * @return Document
     */
    public function setMedia(\Moz\Moz\AdminBundle\Entity\MediaScheme $media = null)
    {
        $this->media = $media;

        return $this;
    }

    /**
     * Get media
     *
     * @return \Moz\Moz\AdminBundle\Entity\MediaScheme 
     */
    public function getMedia()
    {
        return $this->media;
    }
}
