<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ProjectContact
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ProjectContactRepository")
 */
class ProjectContact
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var boolean
     *
     * @ORM\Column(name="isPrimary", type="boolean")
     */
    private $isPrimary;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project")
     */
    private $project;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Contact",cascade={"persist"})
     */
    private $contact;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     */
    private $type;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set isPrimary
     *
     * @param boolean $isPrimary
     * @return ProjectContact
     */
    public function setIsPrimary($isPrimary)
    {
        $this->isPrimary = $isPrimary;

        return $this;
    }

    /**
     * Get isPrimary
     *
     * @return boolean 
     */
    public function getIsPrimary()
    {
        return $this->isPrimary;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return ProjectContact
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set contact
     *
     * @param \Moz\ProjectBundle\Entity\Contact $contact
     * @return ProjectContact
     */
    public function setContact(\Moz\ProjectBundle\Entity\Contact $contact = null)
    {
        $this->contact = $contact;

        return $this;
    }

    /**
     * Get contact
     *
     * @return \Moz\ProjectBundle\Entity\Contact 
     */
    public function getContact()
    {
        return $this->contact;
    }

    /**
     * Set type
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $type
     * @return ProjectContact
     */
    public function setType(\Moz\ProjectBundle\Entity\CategoryValues $type = null)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getType()
    {
        return $this->type;
    }
}
