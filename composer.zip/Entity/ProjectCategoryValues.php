<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ProjectCategoryValues
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ProjectCategoryValuesRepository")
 */
class ProjectCategoryValues
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project")
     */
    private $Project;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     */
    private $value;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set Project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return ProjectCategoryValues
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->Project = $project;

        return $this;
    }

    /**
     * Get Project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->Project;
    }

    /**
     * Set value
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $value
     * @return ProjectCategoryValues
     */
    public function setValue(\Moz\ProjectBundle\Entity\CategoryValues $value = null)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getValue()
    {
        return $this->value;
    }
}
