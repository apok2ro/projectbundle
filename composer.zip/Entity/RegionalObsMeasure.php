<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * RegionalObsMeasure
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\RegionalObsMeasureRepository")
 */
class RegionalObsMeasure
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\RegionalObs")
     */
    private $observation;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\RegionalObsActor", mappedBy="measure", cascade={"persist"})
     *
     */
    private $actors;


    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text", nullable=true)
     */
    private $name;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return RegionalObsMeasure
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->actors = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Set observation
     *
     * @param \Moz\ProjectBundle\Entity\RegionalObs $observation
     * @return RegionalObsMeasure
     */
    public function setObservation(\Moz\ProjectBundle\Entity\RegionalObs $observation = null)
    {
        $this->observation = $observation;

        return $this;
    }

    /**
     * Get observation
     *
     * @return \Moz\ProjectBundle\Entity\RegionalObs 
     */
    public function getObservation()
    {
        return $this->observation;
    }

    /**
     * Add actors
     *
     * @param \Moz\ProjectBundle\Entity\RegionalObsActor $actors
     * @return RegionalObsMeasure
     */
    public function addActor(\Moz\ProjectBundle\Entity\RegionalObsActor $actors)
    {
        $actors->setMeasure($this);
        $this->actors[] = $actors;

        return $this;
    }

    /**
     * Remove actors
     *
     * @param \Moz\ProjectBundle\Entity\RegionalObsActor $actors
     */
    public function removeActor(\Moz\ProjectBundle\Entity\RegionalObsActor $actors)
    {
        $this->actors->removeElement($actors);
    }

    /**
     * Get actors
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getActors()
    {
        return $this->actors;
    }
}
