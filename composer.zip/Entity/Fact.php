<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Fact
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\FactRepository")
 */
class Fact
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $project;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Location")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $location;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Region")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $region;
    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\District")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $district;
    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Territory")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $Territory;



    /**
     * @var float
     *
     * @ORM\Column(name="locationPercentage", type="float")
     */
    private $locationPercentage;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Sector")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $principalSector;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Sector")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $parentSector;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Sector")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $ancestorSector;


    /**
     * @var float
     *
     * @ORM\Column(name="principalSectorPercentage", type="float")
     */
    private $principalSectorPercentage;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Sector")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $secondarySector;


    /**
     * @var float
     *
     * @ORM\Column(name="sencondarySectorPercentage", type="float")
     */
    private $secondarySectorPercentage;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $organisation;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\OrganisationGroup")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $organisationGroup;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\OrganisationType")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $organisationType;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $TypeAssistance;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $finInstrument;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $bugdet;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $status;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $implementation;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $finsource;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $level;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $implAgency;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $execAgency;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $benAgency;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $min;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\OrganisationGroup")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $mingroup;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Program")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $program;

    /**
     * @var float
     *
     * @ORM\Column(name="eng_eff", type="float", nullable=true)
     */
    private $engEff;

    /**
     * @var float
     *
     * @ORM\Column(name="dib_eff", type="float", nullable=true)
     */
    private $dibEff;

    /**
     * @var float
     *
     * @ORM\Column(name="exp_eff", type="float", nullable=true)
     */
    private $expEff;

    /**
     * @var float
     *
     * @ORM\Column(name="eng_prev", type="float", nullable=true)
     */
    private $engPrev;

    /**
     * @var float
     *
     * @ORM\Column(name="dib_prev", type="float", nullable=true)
     */
    private $dibPrev;

    /**
     * @var float
     *
     * @ORM\Column(name="exp_prev", type="float", nullable=true)
     */
    private $expPrev;

    /**
     * @var string
     *
     * @ORM\Column(name="start_date", type="text", nullable=true)
     */
    private $startDate;

    /**
     * @var string
     *
     * @ORM\Column(name="end_date", type="text", nullable=true)
     */
    private $Enddate;


    /**
     * @var boolean
     *
     * @ORM\Column(name="approved", type="boolean")
     */
    private $approved;

    /**
     * @var string
     *
     * @ORM\Column(name="nregion", type="text", nullable=true)
     */
    private $nregion;

   /**
     * @var string
     *
     * @ORM\Column(name="ndistrict", type="text", nullable=true)
     */
    private $ndistrict;
	
	 /**
     * @var integer
     *
     * @ORM\Column(name="cost", type="integer", nullable=true)
     */
    private $cost;
	

   /**
     * @var string
     *
     * @ORM\Column(name="nterritory", type="text", nullable=true)
     */
    private $nterritory;

    /**
     * @var string
     *
     * @ORM\Column(name="prin_sector", type="text", nullable=true)
     */
    private $prinSector;


    /**
     * @var string
     *
     * @ORM\Column(name="sec_sector", type="text", nullable=true)
     */
     private $secSector;


    /**
     * @var string
     *
     * @ORM\Column(name="ances_sector", type="text", nullable=true)
     */
     private $ancesSector;


    /**
     * @var string
     *
     * @ORM\Column(name="res_org", type="text", nullable=true)
     */
    private $resOrg;


    /**
     * @var string
     *
     * @ORM\Column(name="exec_org", type="text", nullable=true)
     */
    private $execOrg;


    /**
     * @var string
     *
     * @ORM\Column(name="ben_org", type="text", nullable=true)
     */
    private $benOrg;


    /**
     * @var string
     *
     * @ORM\Column(name="impl_org", type="text", nullable=true)
     */
    private $implOrg;


    /**
     * @var string
     *
     * @ORM\Column(name="min_org", type="text", nullable=true)
     */
    private $minOrg;

    /**
     * @var string
     *
     * @ORM\Column(name="org", type="text", nullable=true)
     */
    private $org;



    /**
     * @var string
     *
     * @ORM\Column(name="org_group", type="text", nullable=true)
     */
    private $orgGroup;

    /**
     * @var string
     *
     * @ORM\Column(name="org_type", type="text", nullable=true)
     */
    private $orgType;


    /**
     * @var string
     *
     * @ORM\Column(name="state", type="text", nullable=true)
     */
    private $state;


    /**
     * @var string
     *
     * @ORM\Column(name="fin_instr", type="text", nullable=true)
     */
    private $financingInstrument;


    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;



    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Currency")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $currency;



    /**
     * @var string
     *
     * @ORM\Column(name="type_ass", type="text", nullable=true)
     */
    private $typeAss;



    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $sectorialGroup;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $departementalGroup;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $contractingAgency;


    /**
     * @var string
     *
     * @ORM\Column(name="sectorialgroup_name", type="text", nullable=true)
     */
    private $sectorialGroupName;

    /**
     * @var string
     *
     * @ORM\Column(name="departementalgroup_name", type="text", nullable=true)
     */
    private $departementalGroupName;

    /**
     * @var string
     *
     * @ORM\Column(name="contractingagency_name", type="text", nullable=true)
     */
    private $contractingAgencyName;





    private $project__;
    private $project___;
    private $project____;
    private $program_;
    private $program__;




    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set locationPercentage
     *
     * @param float $locationPercentage
     * @return Fact
     */
    public function setLocationPercentage($locationPercentage)
    {
        $this->locationPercentage = $locationPercentage;

        return $this;
    }

    /**
     * Get locationPercentage
     *
     * @return float 
     */
    public function getLocationPercentage()
    {
        return $this->locationPercentage;
    }

    /**
     * Set principalSectorPercentage
     *
     * @param float $principalSectorPercentage
     * @return Fact
     */
    public function setPrincipalSectorPercentage($principalSectorPercentage)
    {
        $this->principalSectorPercentage = $principalSectorPercentage;

        return $this;
    }

    /**
     * Get principalSectorPercentage
     *
     * @return float 
     */
    public function getPrincipalSectorPercentage()
    {
        return $this->principalSectorPercentage;
    }


    /**
     * Set secondarySectorPercentage
     *
     * @param float $secondarySectorPercentage
     * @return Fact
     */
    public function setSecondarySectorPercentage($secondarySectorPercentage)
    {
        $this->secondarySectorPercentage = $secondarySectorPercentage;

        return $this;
    }

    /**
     * Get secondarySectorPercentage
     *
     * @return float 
     */
    public function getSecondarySectorPercentage()
    {
        return $this->secondarySectorPercentage;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return Fact
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set location
     *
     * @param \Moz\ProjectBundle\Entity\Location $location
     * @return Fact
     */
    public function setLocation(\Moz\ProjectBundle\Entity\Location $location = null)
    {
        $this->location = $location;

        return $this;
    }

    /**
     * Get location
     *
     * @return \Moz\ProjectBundle\Entity\Location 
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Set region
     *
     * @param \Moz\ProjectBundle\Entity\Region $region
     * @return Fact
     */
    public function setRegion(\Moz\ProjectBundle\Entity\Region $region = null)
    {
        $this->region = $region;

        return $this;
    }

    /**
     * Get region
     *
     * @return \Moz\ProjectBundle\Entity\Region 
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * Set district
     *
     * @param \Moz\ProjectBundle\Entity\District $district
     * @return Fact
     */
    public function setDistrict(\Moz\ProjectBundle\Entity\District $district = null)
    {
        $this->district = $district;

        return $this;
    }

    /**
     * Get district
     *
     * @return \Moz\ProjectBundle\Entity\District 
     */
    public function getDistrict()
    {
        return $this->district;
    }

    /**
     * Set Territory
     *
     * @param \Moz\ProjectBundle\Entity\Territory $territory
     * @return Fact
     */
    public function setTerritory(\Moz\ProjectBundle\Entity\Territory $territory = null)
    {
        $this->Territory = $territory;

        return $this;
    }

    /**
     * Get Territory
     *
     * @return \Moz\ProjectBundle\Entity\Territory 
     */
    public function getTerritory()
    {
        return $this->Territory;
    }

    /**
     * Set principalSector
     *
     * @param \Moz\ProjectBundle\Entity\Sector $principalSector
     * @return Fact
     */
    public function setPrincipalSector(\Moz\ProjectBundle\Entity\Sector $principalSector = null)
    {
        $this->principalSector = $principalSector;

        return $this;
    }

    /**
     * Get principalSector
     *
     * @return \Moz\ProjectBundle\Entity\Sector 
     */
    public function getPrincipalSector()
    {
        return $this->principalSector;
    }

    /**
     * Set secondarySector
     *
     * @param \Moz\ProjectBundle\Entity\Sector $secondarySector
     * @return Fact
     */
    public function setSecondarySector(\Moz\ProjectBundle\Entity\Sector $secondarySector = null)
    {
        $this->secondarySector = $secondarySector;

        return $this;
    }

    /**
     * Get secondarySector
     *
     * @return \Moz\ProjectBundle\Entity\Sector 
     */
    public function getSecondarySector()
    {
        return $this->secondarySector;
    }

    /**
     * Set organisation
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $organisation
     * @return Fact
     */
    public function setOrganisation(\Moz\ProjectBundle\Entity\Organisation $organisation = null)
    {
        $this->organisation = $organisation;

        return $this;
    }

    /**
     * Get organisation
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getOrganisation()
    {
        return $this->organisation;
    }

    /**
     * Set organisationGroup
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationGroup $organisationGroup
     * @return Fact
     */
    public function setOrganisationGroup(\Moz\ProjectBundle\Entity\OrganisationGroup $organisationGroup = null)
    {
        $this->organisationGroup = $organisationGroup;

        return $this;
    }

    /**
     * Get organisationGroup
     *
     * @return \Moz\ProjectBundle\Entity\OrganisationGroup 
     */
    public function getOrganisationGroup()
    {
        return $this->organisationGroup;
    }

    /**
     * Set organisationType
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationType $organisationType
     * @return Fact
     */
    public function setOrganisationType(\Moz\ProjectBundle\Entity\OrganisationType $organisationType = null)
    {
        $this->organisationType = $organisationType;

        return $this;
    }

    /**
     * Get organisationType
     *
     * @return \Moz\ProjectBundle\Entity\OrganisationType 
     */
    public function getOrganisationType()
    {
        return $this->organisationType;
    }

    /**
     * Set parentSector
     *
     * @param \Moz\ProjectBundle\Entity\Sector $parentSector
     * @return Fact
     */
    public function setParentSector(\Moz\ProjectBundle\Entity\Sector $parentSector = null)
    {
        $this->parentSector = $parentSector;

        return $this;
    }

    /**
     * Get parentSector
     *
     * @return \Moz\ProjectBundle\Entity\Sector 
     */
    public function getParentSector()
    {
        return $this->parentSector;
    }

    /**
     * Set ancestorSector
     *
     * @param \Moz\ProjectBundle\Entity\Sector $ancestorSector
     * @return Fact
     */
    public function setAncestorSector(\Moz\ProjectBundle\Entity\Sector $ancestorSector = null)
    {
        $this->ancestorSector = $ancestorSector;

        return $this;
    }

    /**
     * Get ancestorSector
     *
     * @return \Moz\ProjectBundle\Entity\Sector 
     */
    public function getAncestorSector()
    {
        return $this->ancestorSector;
    }

    /**
     * Set TypeAssistance
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $typeAssistance
     * @return Fact
     */
    public function setTypeAssistance(\Moz\ProjectBundle\Entity\CategoryValues $typeAssistance = null)
    {
        $this->TypeAssistance = $typeAssistance;

        return $this;
    }

    /**
     * Get TypeAssistance
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getTypeAssistance()
    {
        return $this->TypeAssistance;
    }

    /**
     * Set finInstrument
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $finInstrument
     * @return Fact
     */
    public function setFinInstrument(\Moz\ProjectBundle\Entity\CategoryValues $finInstrument = null)
    {
        $this->finInstrument = $finInstrument;

        return $this;
    }

    /**
     * Get finInstrument
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getFinInstrument()
    {
        return $this->finInstrument;
    }

    /**
     * Set bugdet
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $bugdet
     * @return Fact
     */
    public function setBugdet(\Moz\ProjectBundle\Entity\CategoryValues $bugdet = null)
    {
        $this->bugdet = $bugdet;

        return $this;
    }

    /**
     * Get bugdet
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getBugdet()
    {
        return $this->bugdet;
    }

    /**
     * Set status
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $status
     * @return Fact
     */
    public function setStatus(\Moz\ProjectBundle\Entity\CategoryValues $status = null)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set implAgency
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $implAgency
     * @return Fact
     */
    public function setImplAgency(\Moz\ProjectBundle\Entity\Organisation $implAgency = null)
    {
        $this->implAgency = $implAgency;

        return $this;
    }

    /**
     * Get implAgency
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getImplAgency()
    {
        return $this->implAgency;
    }

    /**
     * Set execAgency
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $execAgency
     * @return Fact
     */
    public function setExecAgency(\Moz\ProjectBundle\Entity\Organisation $execAgency = null)
    {
        $this->execAgency = $execAgency;

        return $this;
    }

    /**
     * Get execAgency
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getExecAgency()
    {
        return $this->execAgency;
    }

    /**
     * Set benAgency
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $benAgency
     * @return Fact
     */
    public function setBenAgency(\Moz\ProjectBundle\Entity\Organisation $benAgency = null)
    {
        $this->benAgency = $benAgency;

        return $this;
    }

    /**
     * Get benAgency
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getBenAgency()
    {
        return $this->benAgency;
    }

    /**
     * Set min
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $min
     * @return Fact
     */
    public function setMin(\Moz\ProjectBundle\Entity\Organisation $min = null)
    {
        $this->min = $min;

        return $this;
    }

    /**
     * Get min
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getMin()
    {
        return $this->min;
    }

    /**
     * Set mingroup
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationGroup $mingroup
     * @return Fact
     */
    public function setMingroup(\Moz\ProjectBundle\Entity\OrganisationGroup $mingroup = null)
    {
        $this->mingroup = $mingroup;

        return $this;
    }

    /**
     * Get mingroup
     *
     * @return \Moz\ProjectBundle\Entity\OrganisationGroup 
     */
    public function getMingroup()
    {
        return $this->mingroup;
    }

    /**
     * Set program
     *
     * @param \Moz\ProjectBundle\Entity\Program $program
     * @return Fact
     */
    public function setProgram(\Moz\ProjectBundle\Entity\Program $program = null)
    {
        $this->program = $program;

        return $this;
    }

    /**
     * Get program
     *
     * @return \Moz\ProjectBundle\Entity\Program 
     */
    public function getProgram()
    {
        return $this->program;
    }




    /**
     * Set engEff
     *
     * @param float $engEff
     * @return Fact
     */
    public function setEngEff($engEff)
    {
        $this->engEff = $engEff;

        return $this;
    }

    /**
     * Get engEff
     *
     * @return float 
     */
    public function getEngEff()
    {
        return $this->engEff;
    }

    /**
     * Set dibEff
     *
     * @param float $dibEff
     * @return Fact
     */
    public function setDibEff($dibEff)
    {
        $this->dibEff = $dibEff;

        return $this;
    }

    /**
     * Get dibEff
     *
     * @return float 
     */
    public function getDibEff()
    {
        return $this->dibEff;
    }

    /**
     * Set expEff
     *
     * @param float $expEff
     * @return Fact
     */
    public function setExpEff($expEff)
    {
        $this->expEff = $expEff;

        return $this;
    }

    /**
     * Get expEff
     *
     * @return float 
     */
    public function getExpEff()
    {
        return $this->expEff;
    }

    /**
     * Set engPrev
     *
     * @param float $engPrev
     * @return Fact
     */
    public function setEngPrev($engPrev)
    {
        $this->engPrev = $engPrev;

        return $this;
    }

    /**
     * Get engPrev
     *
     * @return float 
     */
    public function getEngPrev()
    {
        return $this->engPrev;
    }

    /**
     * Set dibPrev
     *
     * @param float $dibPrev
     * @return Fact
     */
    public function setDibPrev($dibPrev)
    {
        $this->dibPrev = $dibPrev;

        return $this;
    }

    /**
     * Get dibPrev
     *
     * @return float 
     */
    public function getDibPrev()
    {
        return $this->dibPrev;
    }

    /**
     * Set expPrev
     *
     * @param float $expPrev
     * @return Fact
     */
    public function setExpPrev($expPrev)
    {
        $this->expPrev = $expPrev;

        return $this;
    }

    /**
     * Get expPrev
     *
     * @return float 
     */
    public function getExpPrev()
    {
        return $this->expPrev;
    }

    /**
     * Set startDate
     *
     * @param string $startDate
     * @return Fact
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return string 
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set Enddate
     *
     * @param string $enddate
     * @return Fact
     */
    public function setEnddate($enddate)
    {
        $this->Enddate = $enddate;

        return $this;
    }

    /**
     * Get Enddate
     *
     * @return string 
     */
    public function getEnddate()
    {
        return $this->Enddate;
    }

    /**
     * Set approved
     *
     * @param boolean $approved
     * @return Fact
     */
    public function setApproved($approved)
    {
        $this->approved = $approved;

        return $this;
    }

    /**
     * Get approved
     *
     * @return boolean 
     */
    public function getApproved()
    {
        return $this->approved;
    }

    /**
     * Set nregion
     *
     * @param string $nregion
     * @return Fact
     */
    public function setNregion($nregion)
    {
        $this->nregion = $nregion;

        return $this;
    }

    /**
     * Get nregion
     *
     * @return string 
     */
    public function getNregion()
    {
        return $this->nregion;
    }

    /**
     * Set ndistrict
     *
     * @param string $ndistrict
     * @return Fact
     */
    public function setNdistrict($ndistrict)
    {
        $this->ndistrict = $ndistrict;

        return $this;
    }

    /**
     * Get ndistrict
     *
     * @return string 
     */
    public function getNdistrict()
    {
        return $this->ndistrict;
    }

    /**
     * Set nterritory
     *
     * @param string $nterritory
     * @return Fact
     */
    public function setNterritory($nterritory)
    {
        $this->nterritory = $nterritory;

        return $this;
    }

    /**
     * Get nterritory
     *
     * @return string 
     */
    public function getNterritory()
    {
        return $this->nterritory;
    }

    /**
     * Set prinSector
     *
     * @param string $prinSector
     * @return Fact
     */
    public function setPrinSector($prinSector)
    {
        $this->prinSector = $prinSector;

        return $this;
    }

    /**
     * Get prinSector
     *
     * @return string 
     */
    public function getPrinSector()
    {
        return $this->prinSector;
    }

    /**
     * Set secSector
     *
     * @param string $secSector
     * @return Fact
     */
    public function setSecSector($secSector)
    {
        $this->secSector = $secSector;

        return $this;
    }

    /**
     * Get secSector
     *
     * @return string 
     */
    public function getSecSector()
    {
        return $this->secSector;
    }

    /**
     * Set ancesSector
     *
     * @param string $ancesSector
     * @return Fact
     */
    public function setAncesSector($ancesSector)
    {
        $this->ancesSector = $ancesSector;

        return $this;
    }

    /**
     * Get ancesSector
     *
     * @return string 
     */
    public function getAncesSector()
    {
        return $this->ancesSector;
    }

    /**
     * Set resOrg
     *
     * @param string $resOrg
     * @return Fact
     */
    public function setResOrg($resOrg)
    {
        $this->resOrg = $resOrg;

        return $this;
    }

    /**
     * Get resOrg
     *
     * @return string 
     */
    public function getResOrg()
    {
        return $this->resOrg;
    }

    /**
     * Set execOrg
     *
     * @param string $execOrg
     * @return Fact
     */
    public function setExecOrg($execOrg)
    {
        $this->execOrg = $execOrg;

        return $this;
    }

    /**
     * Get execOrg
     *
     * @return string 
     */
    public function getExecOrg()
    {
        return $this->execOrg;
    }

    /**
     * Set benOrg
     *
     * @param string $benOrg
     * @return Fact
     */
    public function setBenOrg($benOrg)
    {
        $this->benOrg = $benOrg;

        return $this;
    }

    /**
     * Get benOrg
     *
     * @return string 
     */
    public function getBenOrg()
    {
        return $this->benOrg;
    }

    /**
     * Set implOrg
     *
     * @param string $implOrg
     * @return Fact
     */
    public function setImplOrg($implOrg)
    {
        $this->implOrg = $implOrg;

        return $this;
    }

    /**
     * Get implOrg
     *
     * @return string 
     */
    public function getImplOrg()
    {
        return $this->implOrg;
    }

    /**
     * Set minOrg
     *
     * @param string $minOrg
     * @return Fact
     */
    public function setMinOrg($minOrg)
    {
        $this->minOrg = $minOrg;

        return $this;
    }

    /**
     * Get minOrg
     *
     * @return string 
     */
    public function getMinOrg()
    {
        return $this->minOrg;
    }

    /**
     * Set orgGroup
     *
     * @param string $orgGroup
     * @return Fact
     */
    public function setOrgGroup($orgGroup)
    {
        $this->orgGroup = $orgGroup;

        return $this;
    }

    /**
     * Get orgGroup
     *
     * @return string 
     */
    public function getOrgGroup()
    {
        return $this->orgGroup;
    }

    /**
     * Set orgType
     *
     * @param string $orgType
     * @return Fact
     */
    public function setOrgType($orgType)
    {
        $this->orgType = $orgType;

        return $this;
    }

    /**
     * Get orgType
     *
     * @return string 
     */
    public function getOrgType()
    {
        return $this->orgType;
    }

    /**
     * Set state
     *
     * @param string $state
     * @return Fact
     */
    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return string 
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set financingInstrument
     *
     * @param string $financingInstrument
     * @return Fact
     */
    public function setFinancingInstrument($financingInstrument)
    {
        $this->financingInstrument = $financingInstrument;

        return $this;
    }

    /**
     * Get financingInstrument
     *
     * @return string 
     */
    public function getFinancingInstrument()
    {
        return $this->financingInstrument;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Fact
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set currency
     *
     * @param \Moz\ProjectBundle\Entity\Currency $currency
     * @return Fact
     */
    public function setCurrency(\Moz\ProjectBundle\Entity\Currency $currency = null)
    {
        $this->currency = $currency;

        return $this;
    }

    /**
     * Get currency
     *
     * @return \Moz\ProjectBundle\Entity\Currency 
     */
    public function getCurrency()
    {
        return $this->currency;
    }

    /**
     * Set typeAss
     *
     * @param string $typeAss
     * @return Fact
     */
    public function setTypeAss($typeAss)
    {
        $this->typeAss = $typeAss;

        return $this;
    }

    /**
     * Get typeAss
     *
     * @return string 
     */
    public function getTypeAss()
    {
        return $this->typeAss;
    }

    /**
     * Set org
     *
     * @param string $org
     * @return Fact
     */
    public function setOrg($org)
    {
        $this->org = $org;

        return $this;
    }

    /**
     * Get org
     *
     * @return string 
     */
    public function getOrg()
    {
        return $this->org;
    }

    /**
     * Set sectorialGroupName
     *
     * @param string $sectorialGroupName
     * @return Fact
     */
    public function setSectorialGroupName($sectorialGroupName)
    {
        $this->sectorialGroupName = $sectorialGroupName;

        return $this;
    }

    /**
     * Get sectorialGroupName
     *
     * @return string 
     */
    public function getSectorialGroupName()
    {
        return $this->sectorialGroupName;
    }

    /**
     * Set departementalGroupName
     *
     * @param string $departementalGroupName
     * @return Fact
     */
    public function setDepartementalGroupName($departementalGroupName)
    {
        $this->departementalGroupName = $departementalGroupName;

        return $this;
    }

    /**
     * Get departementalGroupName
     *
     * @return string 
     */
    public function getDepartementalGroupName()
    {
        return $this->departementalGroupName;
    }

    /**
     * Set contractingAgencyName
     *
     * @param string $contractingAgencyName
     * @return Fact
     */
    public function setContractingAgencyName($contractingAgencyName)
    {
        $this->contractingAgencyName = $contractingAgencyName;

        return $this;
    }

    /**
     * Get contractingAgencyName
     *
     * @return string 
     */
    public function getContractingAgencyName()
    {
        return $this->contractingAgencyName;
    }

    /**
     * Set sectorialGroup
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $sectorialGroup
     * @return Fact
     */
    public function setSectorialGroup(\Moz\ProjectBundle\Entity\Organisation $sectorialGroup = null)
    {
        $this->sectorialGroup = $sectorialGroup;

        return $this;
    }

    /**
     * Get sectorialGroup
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getSectorialGroup()
    {
        return $this->sectorialGroup;
    }

    /**
     * Set departementalGroup
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $departementalGroup
     * @return Fact
     */
    public function setDepartementalGroup(\Moz\ProjectBundle\Entity\Organisation $departementalGroup = null)
    {
        $this->departementalGroup = $departementalGroup;

        return $this;
    }

    /**
     * Get departementalGroup
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getDepartementalGroup()
    {
        return $this->departementalGroup;
    }

    /**
     * Set contractingAgency
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $contractingAgency
     * @return Fact
     */
    public function setContractingAgency(\Moz\ProjectBundle\Entity\Organisation $contractingAgency = null)
    {
        $this->contractingAgency = $contractingAgency;

        return $this;
    }

    /**
     * Get contractingAgency
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getContractingAgency()
    {
        return $this->contractingAgency;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Fact
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set cost
     *
     * @param integer $cost
     * @return Fact
     */
    public function setCost($cost)
    {
        $this->cost = $cost;

        return $this;
    }

    /**
     * Get cost
     *
     * @return integer 
     */
    public function getCost()
    {
        return $this->cost;
    }

    /**
     * Set implementation
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $implementation
     * @return Fact
     */
    public function setImplementation(\Moz\ProjectBundle\Entity\CategoryValues $implementation = null)
    {
        $this->implementation = $implementation;

        return $this;
    }

    /**
     * Get implementation
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getImplementation()
    {
        return $this->implementation;
    }

    /**
     * Set finsource
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $finsource
     * @return Fact
     */
    public function setFinsource(\Moz\ProjectBundle\Entity\CategoryValues $finsource = null)
    {
        $this->finsource = $finsource;

        return $this;
    }

    /**
     * Get finsource
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getFinsource()
    {
        return $this->finsource;
    }

    /**
     * Set level
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $level
     * @return Fact
     */
    public function setLevel(\Moz\ProjectBundle\Entity\CategoryValues $level = null)
    {
        $this->level = $level;

        return $this;
    }

    /**
     * Get level
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getLevel()
    {
        return $this->level;
    }
}
