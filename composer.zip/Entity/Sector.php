<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Sector
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\SectorRepository")
 */
class Sector
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Sector")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $parent;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Sector")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $ancestor;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\SectorScheme")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $scheme;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255)
     */
    private $code;

    /**
     * @var string
     *
     * @ORM\Column(name="officialCode", type="string", length=255)
     */
    private $officialCode;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text")
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text")
     */
    private $description;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return Sector
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string 
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set officialCode
     *
     * @param string $officialCode
     * @return Sector
     */
    public function setOfficialCode($officialCode)
    {
        $this->officialCode = $officialCode;

        return $this;
    }

    /**
     * Get officialCode
     *
     * @return string 
     */
    public function getOfficialCode()
    {
        return $this->officialCode;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Sector
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Sector
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set parent
     *
     * @param \Moz\ProjectBundle\Entity\Sector $parent
     * @return Sector
     */
    public function setParent(\Moz\ProjectBundle\Entity\Sector $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \Moz\ProjectBundle\Entity\Sector 
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Set scheme
     *
     * @param \Moz\ProjectBundle\Entity\SectorScheme $scheme
     * @return Sector
     */
    public function setScheme(\Moz\ProjectBundle\Entity\SectorScheme $scheme = null)
    {
        $this->scheme = $scheme;

        return $this;
    }

    /**
     * Get scheme
     *
     * @return \Moz\ProjectBundle\Entity\SectorScheme 
     */
    public function getScheme()
    {
        return $this->scheme;
    }

    /**
     * Set ancestor
     *
     * @param \Moz\ProjectBundle\Entity\Sector $ancestor
     * @return Sector
     */
    public function setAncestor(\Moz\ProjectBundle\Entity\Sector $ancestor = null)
    {
        $this->ancestor = $ancestor;

        return $this;
    }

    /**
     * Get ancestor
     *
     * @return \Moz\ProjectBundle\Entity\Sector 
     */
    public function getAncestor()
    {
        return $this->ancestor;
    }
}
