<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Localisation
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\LocalisationRepository")
 */
class Localisation
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var float
     *
     * @ORM\Column(name="pourcentage", type="float")
     */
    private $pourcentage;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project", inversedBy="locations")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $project;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Location", inversedBy="projects")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $location;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set pourcentage
     *
     * @param float $pourcentage
     * @return Localisation
     */
    public function setPourcentage($pourcentage)
    {
        $this->pourcentage = $pourcentage;

        return $this;
    }

    /**
     * Get pourcentage
     *
     * @return float 
     */
    public function getPourcentage()
    {
        return $this->pourcentage;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return Localisation
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }



    /**
     * Set location
     *
     * @param \Moz\ProjectBundle\Entity\Location $location
     * @return Localisation
     */
    public function setLocation(\Moz\ProjectBundle\Entity\Location $location = null)
    {
        $this->location = $location;

        return $this;
    }

    /**
     * Get location
     *
     * @return \Moz\ProjectBundle\Entity\Location
     */
    public function getLocation()
    {
        return $this->location;
    }
}
