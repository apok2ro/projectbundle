<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ProjectIndicator
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ProjectIndicatorRepository")
 */
class ProjectIndicator
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $project;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Indicator")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $indicator;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return ProjectIndicator
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set indicator
     *
     * @param \Moz\ProjectBundle\Entity\Indicator $indicator
     * @return ProjectIndicator
     */
    public function setIndicator(\Moz\ProjectBundle\Entity\Indicator $indicator = null)
    {
        $this->indicator = $indicator;

        return $this;
    }

    /**
     * Get indicator
     *
     * @return \Moz\ProjectBundle\Entity\Indicator 
     */
    public function getIndicator()
    {
        return $this->indicator;
    }
}
