<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Cube
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\CubeRepository")
 */
class Cube
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project")
     * @ORM\JoinColumn(nullable = true)
     */
    private $project;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Location")
     * @ORM\JoinColumn(nullable = true)
     */
    private $location;



    /**
     * @var float
     *
     * @ORM\Column(name="locationPourcentage", type="float")
     */
    private $locationPourcentage;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Sector")
     * @ORM\JoinColumn(nullable = true)
     */
    private $principalSector;


    /**
     * @var float
     *
     * @ORM\Column(name="principalSectorPourcentage", type="float")
     */
    private $principalSectorPourcentage;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Sector")
     * @ORM\JoinColumn(nullable = true)
     */
    private $secondarySector;


    /**
     * @var float
     *
     * @ORM\Column(name="secondarySectorPourcentage", type="float")
     */
    private $secondarySectorPourcentage;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     */
    private $donor;

    /**
     * @var float
     *
     * @ORM\Column(name="planedEngagement", type="float")
     */
    private $planedEngagement;

    /**
     * @var float
     *
     * @ORM\Column(name="planedDibursement", type="float")
     */
    private $planedDibursement;

    /**
     * @var float
     *
     * @ORM\Column(name="planedExpenditure", type="float")
     */
    private $planedExpenditure;

    /**
     * @var float
     *
     * @ORM\Column(name="actualEngagement", type="float")
     */
    private $actualEngagement;

    /**
     * @var float
     *
     * @ORM\Column(name="actualDibursement", type="float")
     */
    private $actualDibursement;

    /**
     * @var float
     *
     * @ORM\Column(name="actualExpenditure", type="float")
     */
    private $actualExpenditure;

    /**
     * @var float
     *
     * @ORM\Column(name="pipelineEngagement", type="float")
     */
    private $pipelineEngagement;

    /**
     * @var float
     *
     * @ORM\Column(name="pipelineDibursement", type="float")
     */
    private $pipelineDibursement;

    /**
     * @var float
     *
     * @ORM\Column(name="pipelineExpenditure", type="float")
     */
    private $pipelineExpenditure;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->pipelineExpenditure = 0;
        $this->pipelineDibursement = 0;
        $this->pipelineEngagement = 0;
        $this->actualExpenditure = 0;
        $this->actualDibursement = 0;
        $this->actualEngagement = 0;
        $this->planedExpenditure = 0;
        $this->planedDibursement = 0;
        $this->planedEngagement = 0;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set locationPourcentage
     *
     * @param float $locationPourcentage
     * @return Cube
     */
    public function setLocationPourcentage($locationPourcentage)
    {
        $this->locationPourcentage = $locationPourcentage;

        return $this;
    }

    /**
     * Get locationPourcentage
     *
     * @return float 
     */
    public function getLocationPourcentage()
    {
        return $this->locationPourcentage;
    }

    /**
     * Set principalSectorPourcentage
     *
     * @param float $principalSectorPourcentage
     * @return Cube
     */
    public function setPrincipalSectorPourcentage($principalSectorPourcentage)
    {
        $this->principalSectorPourcentage = $principalSectorPourcentage;

        return $this;
    }

    /**
     * Get principalSectorPourcentage
     *
     * @return float 
     */
    public function getPrincipalSectorPourcentage()
    {
        return $this->principalSectorPourcentage;
    }

    /**
     * Set secondarySectorPourcentage
     *
     * @param float $secondarySectorPourcentage
     * @return Cube
     */
    public function setSecondarySectorPourcentage($secondarySectorPourcentage)
    {
        $this->secondarySectorPourcentage = $secondarySectorPourcentage;

        return $this;
    }

    /**
     * Get secondarySectorPourcentage
     *
     * @return float 
     */
    public function getSecondarySectorPourcentage()
    {
        return $this->secondarySectorPourcentage;
    }


    /**
     * Set planedEngagement
     *
     * @param float $planedEngagement
     * @return Cube
     */
    public function setPlanedEngagement($planedEngagement)
    {
        $this->planedEngagement = $planedEngagement;

        return $this;
    }

    /**
     * Get planedEngagement
     *
     * @return float 
     */
    public function getPlanedEngagement()
    {
        return $this->planedEngagement;
    }

    /**
     * Set planedDibursement
     *
     * @param float $planedDibursement
     * @return Cube
     */
    public function setPlanedDibursement($planedDibursement)
    {
        $this->planedDibursement = $planedDibursement;

        return $this;
    }

    /**
     * Get planedDibursement
     *
     * @return float 
     */
    public function getPlanedDibursement()
    {
        return $this->planedDibursement;
    }

    /**
     * Set planedExpenditure
     *
     * @param float $planedExpenditure
     * @return Cube
     */
    public function setPlanedExpenditure($planedExpenditure)
    {
        $this->planedExpenditure = $planedExpenditure;

        return $this;
    }

    /**
     * Get planedExpenditure
     *
     * @return float 
     */
    public function getPlanedExpenditure()
    {
        return $this->planedExpenditure;
    }

    /**
     * Set actualEngagement
     *
     * @param float $actualEngagement
     * @return Cube
     */
    public function setActualEngagement($actualEngagement)
    {
        $this->actualEngagement = $actualEngagement;

        return $this;
    }

    /**
     * Get actualEngagement
     *
     * @return float 
     */
    public function getActualEngagement()
    {
        return $this->actualEngagement;
    }

    /**
     * Set actualDibursement
     *
     * @param float $actualDibursement
     * @return Cube
     */
    public function setActualDibursement($actualDibursement)
    {
        $this->actualDibursement = $actualDibursement;

        return $this;
    }

    /**
     * Get actualDibursement
     *
     * @return float 
     */
    public function getActualDibursement()
    {
        return $this->actualDibursement;
    }

    /**
     * Set actualExpenditure
     *
     * @param float $actualExpenditure
     * @return Cube
     */
    public function setActualExpenditure($actualExpenditure)
    {
        $this->actualExpenditure = $actualExpenditure;

        return $this;
    }

    /**
     * Get actualExpenditure
     *
     * @return float 
     */
    public function getActualExpenditure()
    {
        return $this->actualExpenditure;
    }

    /**
     * Set pipelineEngagement
     *
     * @param float $pipelineEngagement
     * @return Cube
     */
    public function setPipelineEngagement($pipelineEngagement)
    {
        $this->pipelineEngagement = $pipelineEngagement;

        return $this;
    }

    /**
     * Get pipelineEngagement
     *
     * @return float 
     */
    public function getPipelineEngagement()
    {
        return $this->pipelineEngagement;
    }

    /**
     * Set pipelineDibursement
     *
     * @param float $pipelineDibursement
     * @return Cube
     */
    public function setPipelineDibursement($pipelineDibursement)
    {
        $this->pipelineDibursement = $pipelineDibursement;

        return $this;
    }

    /**
     * Get pipelineDibursement
     *
     * @return float 
     */
    public function getPipelineDibursement()
    {
        return $this->pipelineDibursement;
    }

    /**
     * Set pipelineExpenditure
     *
     * @param float $pipelineExpenditure
     * @return Cube
     */
    public function setPipelineExpenditure($pipelineExpenditure)
    {
        $this->pipelineExpenditure = $pipelineExpenditure;

        return $this;
    }

    /**
     * Get pipelineExpenditure
     *
     * @return float 
     */
    public function getPipelineExpenditure()
    {
        return $this->pipelineExpenditure;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return Cube
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set location
     *
     * @param \Moz\ProjectBundle\Entity\Location $location
     * @return Cube
     */
    public function setLocation(\Moz\ProjectBundle\Entity\Location $location = null)
    {
        $this->location = $location;

        return $this;
    }

    /**
     * Get location
     *
     * @return \Moz\ProjectBundle\Entity\Location 
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Set principalSector
     *
     * @param \Moz\ProjectBundle\Entity\Sector $principalSector
     * @return Cube
     */
    public function setPrincipalSector(\Moz\ProjectBundle\Entity\Sector $principalSector = null)
    {
        $this->principalSector = $principalSector;

        return $this;
    }

    /**
     * Get principalSector
     *
     * @return \Moz\ProjectBundle\Entity\Sector 
     */
    public function getPrincipalSector()
    {
        return $this->principalSector;
    }

    /**
     * Set secondarySector
     *
     * @param \Moz\ProjectBundle\Entity\Sector $secondarySector
     * @return Cube
     */
    public function setSecondarySector(\Moz\ProjectBundle\Entity\Sector $secondarySector = null)
    {
        $this->secondarySector = $secondarySector;

        return $this;
    }

    /**
     * Get secondarySector
     *
     * @return \Moz\ProjectBundle\Entity\Sector 
     */
    public function getSecondarySector()
    {
        return $this->secondarySector;
    }



    /**
     * Set donor
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $donor
     * @return Cube
     */
    public function setDonor(\Moz\ProjectBundle\Entity\Organisation $donor = null)
    {
        $this->donor = $donor;

        return $this;
    }

    /**
     * Get donor
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getDonor()
    {
        return $this->donor;
    }
}
