<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Program
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ProgramRepository")
 */
class Program
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text")
     */
    private $name;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\ProgramSetting")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $setting;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Program")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $parent;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Program
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set setting
     *
     * @param \Moz\ProjectBundle\Entity\ProgramSetting $setting
     * @return Program
     */
    public function setSetting(\Moz\ProjectBundle\Entity\ProgramSetting $setting = null)
    {
        $this->setting = $setting;

        return $this;
    }

    /**
     * Get setting
     *
     * @return \Moz\ProjectBundle\Entity\ProgramSetting 
     */
    public function getSetting()
    {
        return $this->setting;
    }

    /**
     * Set parent
     *
     * @param \Moz\ProjectBundle\Entity\Program $parent
     * @return Program
     */
    public function setParent(\Moz\ProjectBundle\Entity\Program $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \Moz\ProjectBundle\Entity\Program 
     */
    public function getParent()
    {
        return $this->parent;
    }
}
