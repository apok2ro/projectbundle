<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Territory
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\TerritoryRepository")
 */
class Territory
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text")
     */
    private $name;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Region")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $region;


    /**
     * @var boolean
     *
     * @ORM\Column(name="valid", type="boolean")
     */
    private $valid;
	
		
	/**
     * @var string
     *
     * @ORM\Column(name="latitude", type="text", nullable=true)
     */
    private $latitute;
	
		
	/**
     * @var string
     *
     * @ORM\Column(name="longitude", type="text", nullable=true)
     */
    private $longitude;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Territory
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set region
     *
     * @param \Moz\ProjectBundle\Entity\Region $region
     * @return Territory
     */
    public function setRegion(\Moz\ProjectBundle\Entity\Region $region = null)
    {
        $this->region = $region;

        return $this;
    }

    /**
     * Get region
     *
     * @return \Moz\ProjectBundle\Entity\Region 
     */
    public function getRegion()
    {
        return $this->region;
    }

    /**
     * Set valid
     *
     * @param boolean $valid
     * @return Territory
     */
    public function setValid($valid)
    {
        $this->valid = $valid;

        return $this;
    }

    /**
     * Get valid
     *
     * @return boolean 
     */
    public function getValid()
    {
        return $this->valid;
    }

    /**
     * Set latitute
     *
     * @param string $latitute
     * @return Territory
     */
    public function setLatitute($latitute)
    {
        $this->latitute = $latitute;

        return $this;
    }

    /**
     * Get latitute
     *
     * @return string 
     */
    public function getLatitute()
    {
        return $this->latitute;
    }

    /**
     * Set longitude
     *
     * @param string $longitude
     * @return Territory
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    /**
     * Get longitude
     *
     * @return string 
     */
    public function getLongitude()
    {
        return $this->longitude;
    }
}
