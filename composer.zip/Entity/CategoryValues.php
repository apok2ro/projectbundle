<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CategoryValues
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\CategoryValuesRepository")
 */
class CategoryValues
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     */
    private $name;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryClass")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $class;

    /**
     * @var integer
     *
     * @ORM\Column(name="indexColumn", type="integer")
     */
    private $indexColumn;

    /**
     * @var boolean
     *
     * @ORM\Column(name="deleted", type="boolean")
     */
    private $deleted;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return CategoryValues
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set indexColumn
     *
     * @param integer $indexColumn
     * @return CategoryValues
     */
    public function setIndexColumn($indexColumn)
    {
        $this->indexColumn = $indexColumn;

        return $this;
    }

    /**
     * Get indexColumn
     *
     * @return integer 
     */
    public function getIndexColumn()
    {
        return $this->indexColumn;
    }

    /**
     * Set deleted
     *
     * @param boolean $deleted
     * @return CategoryValues
     */
    public function setDeleted($deleted)
    {
        $this->deleted = $deleted;

        return $this;
    }

    /**
     * Get deleted
     *
     * @return boolean 
     */
    public function getDeleted()
    {
        return $this->deleted;
    }

    /**
     * Set class
     *
     * @param \Moz\ProjectBundle\Entity\CategoryClass $class
     * @return CategoryValues
     */
    public function setClass(\Moz\ProjectBundle\Entity\CategoryClass $class = null)
    {
        $this->class = $class;

        return $this;
    }

    /**
     * Get class
     *
     * @return \Moz\ProjectBundle\Entity\CategoryClass 
     */
    public function getClass()
    {
        return $this->class;
    }
}
