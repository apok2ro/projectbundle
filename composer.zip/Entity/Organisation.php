<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Organisation
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\OrganisationRepository")
 */
class Organisation
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="organisation", type="text")
     */
    private $organisation;


    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255, nullable=true)
     */
    private $code;

    /**
     * @var string
     *
     * @ORM\Column(name="acronyme", type="string", length=255, nullable=true)
     */
    private $acronyme;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\OrganisationGroup", inversedBy="organisations")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $group;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set organisation
     *
     * @param string $organisation
     * @return Organisation
     */
    public function setOrganisation($organisation)
    {
        $this->organisation = $organisation;

        return $this;
    }

    /**
     * Get organisation
     *
     * @return string 
     */
    public function getOrganisation()
    {
        return $this->organisation;
    }

    /**
     * Set group
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationGroup $group
     * @return Organisation
     */
    public function setGroup(\Moz\ProjectBundle\Entity\OrganisationGroup $group = null)
    {
        $this->group = $group;

        return $this;
    }

    /**
     * Get group
     *
     * @return \Moz\ProjectBundle\Entity\OrganisationGroup 
     */
    public function getGroup()
    {
        return $this->group;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return Organisation
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string 
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set acronyme
     *
     * @param string $acronyme
     * @return Organisation
     */
    public function setAcronyme($acronyme)
    {
        $this->acronyme = $acronyme;

        return $this;
    }

    /**
     * Get acronyme
     *
     * @return string 
     */
    public function getAcronyme()
    {
        return $this->acronyme;
    }
}
