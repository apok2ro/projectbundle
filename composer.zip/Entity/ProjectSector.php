<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ProjectSector
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ProjectSectorRepository")
 */
class ProjectSector
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project", inversedBy="sectors")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $project;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Sector")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $sector;

    /**
     * @var float
     *
     * @ORM\Column(name="pourcentage", type="float", nullable=true)
     */
    private $pourcentage;


    /**
     * @var integer
     *
     * @ORM\Column(name="classification", type="integer")
     */
    private $classification;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set pourcentage
     *
     * @param float $pourcentage
     * @return ProjectSector
     */
    public function setPourcentage($pourcentage)
    {
        $this->pourcentage = $pourcentage;

        return $this;
    }

    /**
     * Get pourcentage
     *
     * @return float 
     */
    public function getPourcentage()
    {
        return $this->pourcentage;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return ProjectSector
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set sector
     *
     * @param \Moz\ProjectBundle\Entity\Sector $sector
     * @return ProjectSector
     */
    public function setSector(\Moz\ProjectBundle\Entity\Sector $sector = null)
    {
        $this->sector = $sector;

        return $this;
    }

    /**
     * Get sector
     *
     * @return \Moz\ProjectBundle\Entity\Sector 
     */
    public function getSector()
    {
        return $this->sector;
    }

    /**
     * Set classification
     *
     * @param integer $classification
     * @return ProjectSector
     */
    public function setClassification($classification)
    {
        $this->classification = $classification;

        return $this;
    }

    /**
     * Get classification
     *
     * @return integer 
     */
    public function getClassification()
    {
        return $this->classification;
    }
}
