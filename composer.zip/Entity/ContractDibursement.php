<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ContractDibursement
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ContractDibursementRepository")
 */
class ContractDibursement
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var float
     *
     * @ORM\Column(name="amount", type="float", nullable=true)
     */
    private $amount;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="text", nullable=true)
     */
    private $date;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $adjustment;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Contract")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $contract;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Currency")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $currency;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set amount
     *
     * @param float $amount
     * @return ContractDibursement
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return float 
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return ContractDibursement
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set adjustment
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $adjustment
     * @return ContractDibursement
     */
    public function setAdjustment(\Moz\ProjectBundle\Entity\CategoryValues $adjustment = null)
    {
        $this->adjustment = $adjustment;

        return $this;
    }

    /**
     * Get adjustment
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getAdjustment()
    {
        return $this->adjustment;
    }

    /**
     * Set contract
     *
     * @param \Moz\ProjectBundle\Entity\Contract $contract
     * @return ContractDibursement
     */
    public function setContract(\Moz\ProjectBundle\Entity\Contract $contract = null)
    {
        $this->contract = $contract;

        return $this;
    }

    /**
     * Get contract
     *
     * @return \Moz\ProjectBundle\Entity\Contract 
     */
    public function getContract()
    {
        return $this->contract;
    }

    /**
     * Set currency
     *
     * @param \Moz\ProjectBundle\Entity\Currency $currency
     * @return ContractDibursement
     */
    public function setCurrency(\Moz\ProjectBundle\Entity\Currency $currency = null)
    {
        $this->currency = $currency;

        return $this;
    }

    /**
     * Get currency
     *
     * @return \Moz\ProjectBundle\Entity\Currency 
     */
    public function getCurrency()
    {
        return $this->currency;
    }
}
