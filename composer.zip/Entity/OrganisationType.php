<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * OrganisationType
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\OrganisationTypeRepository")
 */
class OrganisationType
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text")
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255)
     */
    private $code;

    /**
     * @var boolean
     *
     * @ORM\Column(name="gouvernemental", type="boolean")
     */
    private $gouvernemental;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\OrganisationGroup", mappedBy="type")
     */
    private $groups;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return OrganisationType
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set code
     *
     * @param string $code
     * @return OrganisationType
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string 
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set gouvernemental
     *
     * @param boolean $gouvernemental
     * @return OrganisationType
     */
    public function setGouvernemental($gouvernemental)
    {
        $this->gouvernemental = $gouvernemental;

        return $this;
    }

    /**
     * Get gouvernemental
     *
     * @return boolean 
     */
    public function getGouvernemental()
    {
        return $this->gouvernemental;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->groups = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add groups
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationGroup $groups
     * @return OrganisationType
     */
    public function addGroup(\Moz\ProjectBundle\Entity\OrganisationGroup $groups)
    {
        $groups->setType($this);
        $this->groups[] = $groups;

        return $this;
    }

    /**
     * Remove groups
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationGroup $groups
     */
    public function removeGroup(\Moz\ProjectBundle\Entity\OrganisationGroup $groups)
    {
        $this->groups->removeElement($groups);
    }

    /**
     * Get groups
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getGroups()
    {
        return $this->groups;
    }
}
