<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * FundingDetail
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\FundingDetailRepository")
 */
class FundingDetail
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="transactionDate", type="text", nullable=true)
     *
     */
    private $transactionDate;

    /**
     * @var float
     *
     * @ORM\Column(name="transactionAmount", type="float", nullable=true)
     */
    private $transactionAmount;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="reportingDate", type="text", nullable=true)
     */
    private $reportingDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateUpdated", type="text", nullable=true)
     */
    private $dateUpdated;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $transactionType;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $adjustmentType;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Currency")
     * @ORM\JoinColumn(nullable = true)
     *
     */
     private $currency;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\FundingBase")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $funding;

    /**
     * @var float
     *
     * @ORM\Column(name="fixedExchangeRate", type="float", nullable=true)
     *
     */
    private $fixedExchangeRate;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Contract")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $contract;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set transactionDate
     *
     * @param \DateTime $transactionDate
     * @return FundingDetail
     */
    public function setTransactionDate($transactionDate)
    {
        $this->transactionDate = $transactionDate;

        return $this;
    }

    /**
     * Get transactionDate
     *
     * @return \DateTime 
     */
    public function getTransactionDate()
    {
        return $this->transactionDate;
    }

   
    /**
     * Set reportingDate
     *
     * @param \DateTime $reportingDate
     * @return FundingDetail
     */
    public function setReportingDate($reportingDate)
    {
        $this->reportingDate = $reportingDate;

        return $this;
    }

    /**
     * Get reportingDate
     *
     * @return \DateTime 
     */
    public function getReportingDate()
    {
        return $this->reportingDate;
    }

    /**
     * Set dateUpdated
     *
     * @param \DateTime $dateUpdated
     * @return FundingDetail
     */
    public function setDateUpdated($dateUpdated)
    {
        $this->dateUpdated = $dateUpdated;

        return $this;
    }

    /**
     * Get dateUpdated
     *
     * @return \DateTime 
     */
    public function getDateUpdated()
    {
        return $this->dateUpdated;
    }

    /**
     * Set transactionType
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $transactionType
     * @return FundingDetail
     */
    public function setTransactionType(\Moz\ProjectBundle\Entity\CategoryValues $transactionType = null)
    {
        $this->transactionType = $transactionType;

        return $this;
    }

    /**
     * Get transactionType
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getTransactionType()
    {
        return $this->transactionType;
    }

    /**
     * Set adjustmentType
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $adjustmentType
     * @return FundingDetail
     */
    public function setAdjustmentType(\Moz\ProjectBundle\Entity\CategoryValues $adjustmentType = null)
    {
        $this->adjustmentType = $adjustmentType;

        return $this;
    }

    /**
     * Get adjustmentType
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getAdjustmentType()
    {
        return $this->adjustmentType;
    }

 
    /**
     * Set funding
     *
     * @param \Moz\ProjectBundle\Entity\FundingBase $funding
     * @return FundingDetail
     */
    public function setFunding(\Moz\ProjectBundle\Entity\FundingBase $funding = null)
    {
        $this->funding = $funding;

        return $this;
    }

    /**
     * Get funding
     *
     * @return \Moz\ProjectBundle\Entity\FundingBase 
     */
    public function getFunding()
    {
        return $this->funding;
    }

    /**
     * Set fixedExchangeRate
     *
     * @param float $fixedExchangeRate
     * @return FundingDetail
     */
    public function setFixedExchangeRate($fixedExchangeRate)
    {
        $this->fixedExchangeRate = $fixedExchangeRate;

        return $this;
    }

    /**
     * Get fixedExchangeRate
     *
     * @return float 
     */
    public function getFixedExchangeRate()
    {
        return $this->fixedExchangeRate;
    }

    /**
     * Set contract
     *
     * @param \Moz\ProjectBundle\Entity\Contract $contract
     * @return FundingDetail
     */
    public function setContract(\Moz\ProjectBundle\Entity\Contract $contract = null)
    {
        $this->contract = $contract;

        return $this;
    }

    /**
     * Get contract
     *
     * @return \Moz\ProjectBundle\Entity\Contract 
     */
    public function getContract()
    {
        return $this->contract;
    }

    /**
     * Set currency
     *
     * @param \Moz\ProjectBundle\Entity\Currency $currency
     * @return FundingDetail
     */
    public function setCurrency(\Moz\ProjectBundle\Entity\Currency $currency = null)
    {
        $this->currency = $currency;

        return $this;
    }

    /**
     * Get currency
     *
     * @return \Moz\ProjectBundle\Entity\Currency 
     */
    public function getCurrency()
    {
        return $this->currency;
    }

   


    /**
     * Set transactionAmount
     *
     * @param float $transactionAmount
     * @return FundingDetail
     */
    public function setTransactionAmount($transactionAmount)
    {
        $this->transactionAmount = $transactionAmount;

        return $this;
    }

    /**
     * Get transactionAmount
     *
     * @return float 
     */
    public function getTransactionAmount()
    {
        return $this->transactionAmount;
    }
}
