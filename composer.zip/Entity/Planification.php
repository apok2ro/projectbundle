<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Planification
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\PlanificationRepository")
 */
class Planification
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var \Date
     *
     * @ORM\Column(name="proposedStart", type="text", nullable=true)
     */
    private $proposedStart;

    /**
     * @var \Date
     *
     * @ORM\Column(name="proposedEnd", type="text", nullable=true)
     */
    private $proposedEnd;

    /**
     * @var \Date
     *
     * @ORM\Column(name="effectiveStart", type="text", nullable=true)
     */
    private $effectiveStart;

    /**
     * @var \Date
     *
     * @ORM\Column(name="effectiveEnd", type="text", nullable=true)
     */
    private $effectiveEnd;

    /**
     * @var boolean
     *
     * @ORM\Column(name="respectfull", type="boolean", nullable=true)
     */
    private $respectfull;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

 
    /**
     * Set respectfull
     *
     * @param boolean $respectfull
     * @return Planification
     */
    public function setRespectfull($respectfull)
    {
        $this->respectfull = $respectfull;

        return $this;
    }

    /**
     * Get respectfull
     *
     * @return boolean 
     */
    public function getRespectfull()
    {
        return $this->respectfull;
    }



    

    /**
     * Set proposedStart
     *
     * @param string $proposedStart
     * @return Planification
     */
    public function setProposedStart($proposedStart)
    {
        $this->proposedStart = $proposedStart;

        return $this;
    }

    /**
     * Get proposedStart
     *
     * @return string 
     */
    public function getProposedStart()
    {
        return $this->proposedStart;
    }

    /**
     * Set proposedEnd
     *
     * @param string $proposedEnd
     * @return Planification
     */
    public function setProposedEnd($proposedEnd)
    {
        $this->proposedEnd = $proposedEnd;

        return $this;
    }

    /**
     * Get proposedEnd
     *
     * @return string 
     */
    public function getProposedEnd()
    {
        return $this->proposedEnd;
    }

    /**
     * Set effectiveStart
     *
     * @param string $effectiveStart
     * @return Planification
     */
    public function setEffectiveStart($effectiveStart)
    {
        $this->effectiveStart = $effectiveStart;

        return $this;
    }

    /**
     * Get effectiveStart
     *
     * @return string 
     */
    public function getEffectiveStart()
    {
        return $this->effectiveStart;
    }

    /**
     * Set effectiveEnd
     *
     * @param string $effectiveEnd
     * @return Planification
     */
    public function setEffectiveEnd($effectiveEnd)
    {
        $this->effectiveEnd = $effectiveEnd;

        return $this;
    }

    /**
     * Get effectiveEnd
     *
     * @return string 
     */
    public function getEffectiveEnd()
    {
        return $this->effectiveEnd;
    }
}
