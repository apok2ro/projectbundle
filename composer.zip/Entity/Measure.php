<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Measure
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\MeasureRepository")
 */
class Measure
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text",nullable=true)
     */
    private $name;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Issue")
     */
    private $issue;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\Actor", mappedBy="measure", cascade={"persist"})
     *
     */
    private $actor;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Measure
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set issue
     *
     * @param \Moz\ProjectBundle\Entity\Issue $issue
     * @return Measure
     */
    public function setIssue(\Moz\ProjectBundle\Entity\Issue $issue = null)
    {
        $this->issue = $issue;

        return $this;
    }

    /**
     * Get issue
     *
     * @return \Moz\ProjectBundle\Entity\Issue 
     */
    public function getIssue()
    {
        return $this->issue;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->actor = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add actor
     *
     * @param \Moz\ProjectBundle\Entity\Actor $actor
     * @return Measure
     */
    public function addActor(\Moz\ProjectBundle\Entity\Actor $actor)
    {
        $actor->setMeasure($this);
        $this->actor[] = $actor;

        return $this;
    }

    /**
     * Remove actor
     *
     * @param \Moz\ProjectBundle\Entity\Actor $actor
     */
    public function removeActor(\Moz\ProjectBundle\Entity\Actor $actor)
    {
        $this->actor->removeElement($actor);
    }

    /**
     * Get actor
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getActor()
    {
        return $this->actor;
    }
}
