<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Contract
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ContractRepository")
 */
class Contract
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=true)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="orgName", type="string", length=255, nullable=true)
     */
    private $orgName;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $category;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $type;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $status;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $project;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Currency")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $totalAmountCurrency;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Currency")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $diburGlobalCurrency;






    /**
     * @var \DateTime
     *
     * @ORM\Column(name="startOfTendering", type="text", nullable=true)
     */
    private $startOfTendering;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="signatureOfContract", type="text", nullable=true)
     */
    private $signatureOfContract;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="contractValidity", type="text", nullable=true)
     */
    private $contractValidity;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="contractCompletion", type="text", nullable=true)
     */
    private $contractCompletion;

    /**
     * @var float
     *
     * @ORM\Column(name="totalAmount", type="float", nullable=true)
     */
    private $totalAmount;

    /**
     * @var float
     *
     * @ORM\Column(name="totalValue", type="float", nullable=true)
     */
    private $totalValue;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="totalPrivateContrDate", type="text", nullable=true)
     */
    private $totalPrivateContrDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="totalNationaleContrRegDate", type="text", nullable=true)
     */
    private $totalNationaleContrRegDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="totalNationaleContrIfiDate", type="text", nullable=true)
     */
    private $totalNationaleContrIfiDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="totalNationaleContrCentDate", type="text", nullable=true)
     */
    private $totalNationaleContrCentDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="totalEcContrInvDate", type="text", nullable=true)
     */
    private $totalEcContrInvDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="totalEcContrIbDate", type="text", nullable=true)
     */
    private $totalEcContrIbDate;


    /**
     * @var float
     *
     * @ORM\Column(name="totalPrivateContrAmount", type="float", nullable=true)
     */
    private $totalPrivateContrAmount;

    /**
     * @var float
     *
     * @ORM\Column(name="totalNationaleContrRegAmount", type="float", nullable=true)
     */
    private $totalNationaleContrRegAmount;

    /**
     * @var float
     *
     * @ORM\Column(name="totalNationaleContrIfiAmount", type="float", nullable=true)
     */
    private $totalNationaleContrIfiAmount;

    /**
     * @var float
     *
     * @ORM\Column(name="totalNationaleContrCentAmount", type="float", nullable=true)
     */
    private $totalNationaleContrCentAmount;

    /**
     * @var float
     *
     * @ORM\Column(name="totalEcContrInvAmount", type="float", nullable=true)
     */
    private $totalEcContrInvAmount;

    /**
     * @var float
     *
     * @ORM\Column(name="totalEcContrIbAmount", type="float", nullable=true)
     */
    private $totalEcContrIbAmount;


    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ContractDibursement", mappedBy="contract",cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $dibursements;


    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ContractOrganisation", mappedBy="contract",cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $organisations;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Contract
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Contract
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set orgName
     *
     * @param string $orgName
     * @return Contract
     */
    public function setOrgName($orgName)
    {
        $this->orgName = $orgName;

        return $this;
    }

    /**
     * Get orgName
     *
     * @return string 
     */
    public function getOrgName()
    {
        return $this->orgName;
    }

    /**
     * Set startOfTendering
     *
     * @param \DateTime $startOfTendering
     * @return Contract
     */
    public function setStartOfTendering($startOfTendering)
    {
        $this->startOfTendering = $startOfTendering;

        return $this;
    }

    /**
     * Get startOfTendering
     *
     * @return \DateTime 
     */
    public function getStartOfTendering()
    {
        return $this->startOfTendering;
    }

    /**
     * Set signatureOfContract
     *
     * @param \DateTime $signatureOfContract
     * @return Contract
     */
    public function setSignatureOfContract($signatureOfContract)
    {
        $this->signatureOfContract = $signatureOfContract;

        return $this;
    }

    /**
     * Get signatureOfContract
     *
     * @return \DateTime 
     */
    public function getSignatureOfContract()
    {
        return $this->signatureOfContract;
    }

    /**
     * Set contractValidity
     *
     * @param \DateTime $contractValidity
     * @return Contract
     */
    public function setContractValidity($contractValidity)
    {
        $this->contractValidity = $contractValidity;

        return $this;
    }

    /**
     * Get contractValidity
     *
     * @return \DateTime 
     */
    public function getContractValidity()
    {
        return $this->contractValidity;
    }

    /**
     * Set contractCompletion
     *
     * @param \DateTime $contractCompletion
     * @return Contract
     */
    public function setContractCompletion($contractCompletion)
    {
        $this->contractCompletion = $contractCompletion;

        return $this;
    }

    /**
     * Get contractCompletion
     *
     * @return \DateTime 
     */
    public function getContractCompletion()
    {
        return $this->contractCompletion;
    }

    /**
     * Set totalAmount
     *
     * @param float $totalAmount
     * @return Contract
     */
    public function setTotalAmount($totalAmount)
    {
        $this->totalAmount = $totalAmount;

        return $this;
    }

    /**
     * Get totalAmount
     *
     * @return float 
     */
    public function getTotalAmount()
    {
        return $this->totalAmount;
    }

    /**
     * Set totalValue
     *
     * @param float $totalValue
     * @return Contract
     */
    public function setTotalValue($totalValue)
    {
        $this->totalValue = $totalValue;

        return $this;
    }

    /**
     * Get totalValue
     *
     * @return float 
     */
    public function getTotalValue()
    {
        return $this->totalValue;
    }

    /**
     * Set totalPrivateContrDate
     *
     * @param \DateTime $totalPrivateContrDate
     * @return Contract
     */
    public function setTotalPrivateContrDate($totalPrivateContrDate)
    {
        $this->totalPrivateContrDate = $totalPrivateContrDate;

        return $this;
    }

    /**
     * Get totalPrivateContrDate
     *
     * @return \DateTime 
     */
    public function getTotalPrivateContrDate()
    {
        return $this->totalPrivateContrDate;
    }

    /**
     * Set totalNationaleContrRegDate
     *
     * @param \DateTime $totalNationaleContrRegDate
     * @return Contract
     */
    public function setTotalNationaleContrRegDate($totalNationaleContrRegDate)
    {
        $this->totalNationaleContrRegDate = $totalNationaleContrRegDate;

        return $this;
    }

    /**
     * Get totalNationaleContrRegDate
     *
     * @return \DateTime 
     */
    public function getTotalNationaleContrRegDate()
    {
        return $this->totalNationaleContrRegDate;
    }

    /**
     * Set totalNationaleContrIfiDate
     *
     * @param \DateTime $totalNationaleContrIfiDate
     * @return Contract
     */
    public function setTotalNationaleContrIfiDate($totalNationaleContrIfiDate)
    {
        $this->totalNationaleContrIfiDate = $totalNationaleContrIfiDate;

        return $this;
    }

    /**
     * Get totalNationaleContrIfiDate
     *
     * @return \DateTime 
     */
    public function getTotalNationaleContrIfiDate()
    {
        return $this->totalNationaleContrIfiDate;
    }

    /**
     * Set totalNationaleContrCentDate
     *
     * @param \DateTime $totalNationaleContrCentDate
     * @return Contract
     */
    public function setTotalNationaleContrCentDate($totalNationaleContrCentDate)
    {
        $this->totalNationaleContrCentDate = $totalNationaleContrCentDate;

        return $this;
    }

    /**
     * Get totalNationaleContrCentDate
     *
     * @return \DateTime 
     */
    public function getTotalNationaleContrCentDate()
    {
        return $this->totalNationaleContrCentDate;
    }

    /**
     * Set totalEcContrInvDate
     *
     * @param \DateTime $totalEcContrInvDate
     * @return Contract
     */
    public function setTotalEcContrInvDate($totalEcContrInvDate)
    {
        $this->totalEcContrInvDate = $totalEcContrInvDate;

        return $this;
    }

    /**
     * Get totalEcContrInvDate
     *
     * @return \DateTime 
     */
    public function getTotalEcContrInvDate()
    {
        return $this->totalEcContrInvDate;
    }

    /**
     * Set totalEcContrIbDate
     *
     * @param \DateTime $totalEcContrIbDate
     * @return Contract
     */
    public function setTotalEcContrIbDate($totalEcContrIbDate)
    {
        $this->totalEcContrIbDate = $totalEcContrIbDate;

        return $this;
    }

    /**
     * Get totalEcContrIbDate
     *
     * @return \DateTime 
     */
    public function getTotalEcContrIbDate()
    {
        return $this->totalEcContrIbDate;
    }

    /**
     * Set totalPrivateContrAmount
     *
     * @param float $totalPrivateContrAmount
     * @return Contract
     */
    public function setTotalPrivateContrAmount($totalPrivateContrAmount)
    {
        $this->totalPrivateContrAmount = $totalPrivateContrAmount;

        return $this;
    }

    /**
     * Get totalPrivateContrAmount
     *
     * @return float 
     */
    public function getTotalPrivateContrAmount()
    {
        return $this->totalPrivateContrAmount;
    }

    /**
     * Set totalNationaleContrRegAmount
     *
     * @param float $totalNationaleContrRegAmount
     * @return Contract
     */
    public function setTotalNationaleContrRegAmount($totalNationaleContrRegAmount)
    {
        $this->totalNationaleContrRegAmount = $totalNationaleContrRegAmount;

        return $this;
    }

    /**
     * Get totalNationaleContrRegAmount
     *
     * @return float 
     */
    public function getTotalNationaleContrRegAmount()
    {
        return $this->totalNationaleContrRegAmount;
    }

    /**
     * Set totalNationaleContrIfiAmount
     *
     * @param float $totalNationaleContrIfiAmount
     * @return Contract
     */
    public function setTotalNationaleContrIfiAmount($totalNationaleContrIfiAmount)
    {
        $this->totalNationaleContrIfiAmount = $totalNationaleContrIfiAmount;

        return $this;
    }

    /**
     * Get totalNationaleContrIfiAmount
     *
     * @return float 
     */
    public function getTotalNationaleContrIfiAmount()
    {
        return $this->totalNationaleContrIfiAmount;
    }

    /**
     * Set totalNationaleContrCentAmount
     *
     * @param float $totalNationaleContrCentAmount
     * @return Contract
     */
    public function setTotalNationaleContrCentAmount($totalNationaleContrCentAmount)
    {
        $this->totalNationaleContrCentAmount = $totalNationaleContrCentAmount;

        return $this;
    }

    /**
     * Get totalNationaleContrCentAmount
     *
     * @return float 
     */
    public function getTotalNationaleContrCentAmount()
    {
        return $this->totalNationaleContrCentAmount;
    }

    /**
     * Set totalEcContrInvAmount
     *
     * @param float $totalEcContrInvAmount
     * @return Contract
     */
    public function setTotalEcContrInvAmount($totalEcContrInvAmount)
    {
        $this->totalEcContrInvAmount = $totalEcContrInvAmount;

        return $this;
    }

    /**
     * Get totalEcContrInvAmount
     *
     * @return float 
     */
    public function getTotalEcContrInvAmount()
    {
        return $this->totalEcContrInvAmount;
    }

    /**
     * Set totalEcContrIbAmount
     *
     * @param float $totalEcContrIbAmount
     * @return Contract
     */
    public function setTotalEcContrIbAmount($totalEcContrIbAmount)
    {
        $this->totalEcContrIbAmount = $totalEcContrIbAmount;

        return $this;
    }

    /**
     * Get totalEcContrIbAmount
     *
     * @return float 
     */
    public function getTotalEcContrIbAmount()
    {
        return $this->totalEcContrIbAmount;
    }

    /**
     * Set category
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $category
     * @return Contract
     */
    public function setCategory(\Moz\ProjectBundle\Entity\CategoryValues $category = null)
    {
        $this->category = $category;

        return $this;
    }

    /**
     * Get category
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * Set type
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $type
     * @return Contract
     */
    public function setType(\Moz\ProjectBundle\Entity\CategoryValues $type = null)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set status
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $status
     * @return Contract
     */
    public function setStatus(\Moz\ProjectBundle\Entity\CategoryValues $status = null)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return \Moz\ProjectBundle\Entity\CategoryValues 
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return Contract
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set totalAmountCurrency
     *
     * @param \Moz\ProjectBundle\Entity\Currency $totalAmountCurrency
     * @return Contract
     */
    public function setTotalAmountCurrency(\Moz\ProjectBundle\Entity\Currency $totalAmountCurrency = null)
    {
        $this->totalAmountCurrency = $totalAmountCurrency;

        return $this;
    }

    /**
     * Get totalAmountCurrency
     *
     * @return \Moz\ProjectBundle\Entity\Currency 
     */
    public function getTotalAmountCurrency()
    {
        return $this->totalAmountCurrency;
    }

    /**
     * Set diburGlobalCurrency
     *
     * @param \Moz\ProjectBundle\Entity\Currency $diburGlobalCurrency
     * @return Contract
     */
    public function setDiburGlobalCurrency(\Moz\ProjectBundle\Entity\Currency $diburGlobalCurrency = null)
    {
        $this->diburGlobalCurrency = $diburGlobalCurrency;

        return $this;
    }

    /**
     * Get diburGlobalCurrency
     *
     * @return \Moz\ProjectBundle\Entity\Currency 
     */
    public function getDiburGlobalCurrency()
    {
        return $this->diburGlobalCurrency;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->dibursements = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add dibursements
     *
     * @param \Moz\ProjectBundle\Entity\ContractDibursement $dibursements
     * @return Contract
     */
    public function addDibursement(\Moz\ProjectBundle\Entity\ContractDibursement $dibursements)
    {
        $dibursements->setContract($this);
        $this->dibursements[] = $dibursements;

        return $this;
    }

    /**
     * Remove dibursements
     *
     * @param \Moz\ProjectBundle\Entity\ContractDibursement $dibursements
     */
    public function removeDibursement(\Moz\ProjectBundle\Entity\ContractDibursement $dibursements)
    {
        $this->dibursements->removeElement($dibursements);
    }

    /**
     * Get dibursements
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getDibursements()
    {
        return $this->dibursements;
    }

    


    /**
     * Add organisations
     *
     * @param \Moz\ProjectBundle\Entity\ContractOrganisation $organisations
     * @return Contract
     */
    public function addOrganisation(\Moz\ProjectBundle\Entity\ContractOrganisation $organisations)
    {
        $organisations->setContract($this);
        $this->organisations[] = $organisations;

        return $this;
    }

    /**
     * Remove organisations
     *
     * @param \Moz\ProjectBundle\Entity\ContractOrganisation $organisations
     */
    public function removeOrganisation(\Moz\ProjectBundle\Entity\ContractOrganisation $organisations)
    {
        $this->organisations->removeElement($organisations);
    }

    /**
     * Get organisations
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getOrganisations()
    {
        return $this->organisations;
    }
}
