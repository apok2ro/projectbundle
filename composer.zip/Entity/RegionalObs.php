<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * RegionalObs
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\RegionalObsRepository")
 */
class RegionalObs
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project")
     */
    private $project;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\RegionalObsMeasure", mappedBy="observation", cascade={"persist"})
     *
     */
    private $measures;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text", nullable=true)
     */
    private $name;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="text", nullable=true)
     */
    private $date;


    /**
     * @var \Boolean
     *
     * @ORM\Column(name="type", type="boolean", nullable= true)
     */
    private $ministry;

    /**
     * @var integer
     *
     * @ORM\Column(name="source", type="integer", nullable=true)
     */
    private $source;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return RegionalObs
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return RegionalObs
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getDate()
    {
        return $this->date;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->measures = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Set project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return RegionalObs
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->project = $project;

        return $this;
    }

    /**
     * Get project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Add measures
     *
     * @param \Moz\ProjectBundle\Entity\RegionalObsMeasure $measures
     * @return RegionalObs
     */
    public function addMeasure(\Moz\ProjectBundle\Entity\RegionalObsMeasure $measures)
    {
        $measures->setObservation($this);
        $this->measures[] = $measures;

        return $this;
    }

    /**
     * Remove measures
     *
     * @param \Moz\ProjectBundle\Entity\RegionalObsMeasure $measures
     */
    public function removeMeasure(\Moz\ProjectBundle\Entity\RegionalObsMeasure $measures)
    {
        $this->measures->removeElement($measures);
    }

    /**
     * Get measures
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMeasures()
    {
        return $this->measures;
    }

    /**
     * Set ministry
     *
     * @param boolean $ministry
     * @return RegionalObs
     */
    public function setMinistry($ministry)
    {
        $this->ministry = $ministry;

        return $this;
    }

    /**
     * Get ministry
     *
     * @return boolean 
     */
    public function getMinistry()
    {
        return $this->ministry;
    }

    /**
     * Set source
     *
     * @param integer $source
     * @return RegionalObs
     */
    public function setSource($source)
    {
        $this->source = $source;

        return $this;
    }

    /**
     * Get source
     *
     * @return integer 
     */
    public function getSource()
    {
        return $this->source;
    }
}
