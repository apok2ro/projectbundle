<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ProjectDocument
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ProjectDocumentRepository")
 */
class ProjectDocument
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Project")
     */
    private $Project;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Document", cascade={"persist"})
     */
    private $document;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set Project
     *
     * @param \Moz\ProjectBundle\Entity\Project $project
     * @return ProjectDocument
     */
    public function setProject(\Moz\ProjectBundle\Entity\Project $project = null)
    {
        $this->Project = $project;

        return $this;
    }

    /**
     * Get Project
     *
     * @return \Moz\ProjectBundle\Entity\Project 
     */
    public function getProject()
    {
        return $this->Project;
    }

    

    /**
     * Set document
     *
     * @param \Moz\ProjectBundle\Entity\Document $document
     * @return ProjectDocument
     */
    public function setDocument(\Moz\ProjectBundle\Entity\Document $document = null)
    {
        $this->document = $document;

        return $this;
    }

    /**
     * Get document
     *
     * @return \Moz\ProjectBundle\Entity\Document 
     */
    public function getDocument()
    {
        return $this->document;
    }
}
