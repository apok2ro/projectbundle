<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Region
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\RegionRepository")
 */
class Region
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="text")
     */
    private $name;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Country")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $country;

    /**
     * @var boolean
     *
     * @ORM\Column(name="valid", type="boolean")
     */
    private $valid;
	
	/**
     * @var string
     *
     * @ORM\Column(name="latitude", type="text", nullable=true)
     */
    private $latitute;
	
		
	/**
     * @var string
     *
     * @ORM\Column(name="longitude", type="text", nullable=true)
     */
    private $longitude;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Region
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set country
     *
     * @param \Moz\ProjectBundle\Entity\Country $country
     * @return Region
     */
    public function setCountry(\Moz\ProjectBundle\Entity\Country $country = null)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return \Moz\ProjectBundle\Entity\Country 
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Set valid
     *
     * @param boolean $valid
     * @return Region
     */
    public function setValid($valid)
    {
        $this->valid = $valid;

        return $this;
    }

    /**
     * Get valid
     *
     * @return boolean 
     */
    public function getValid()
    {
        return $this->valid;
    }

    /**
     * Set latitute
     *
     * @param string $latitute
     * @return Region
     */
    public function setLatitute($latitute)
    {
        $this->latitute = $latitute;

        return $this;
    }

    /**
     * Get latitute
     *
     * @return string 
     */
    public function getLatitute()
    {
        return $this->latitute;
    }

    /**
     * Set longitude
     *
     * @param string $longitude
     * @return Region
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    /**
     * Get longitude
     *
     * @return string 
     */
    public function getLongitude()
    {
        return $this->longitude;
    }
}
