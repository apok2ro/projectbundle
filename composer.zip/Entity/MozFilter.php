<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * MozFilter
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\MozFilterRepository")
 */
class MozFilter
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="zlist", type="text", nullable=true)
     */
    private $zlist;

    /**
     * @var string
     *
     * @ORM\Column(name="zcolumn", type="text", nullable=true)
     */
    private $zcolumn;

    /**
     * @var string
     *
     * @ORM\Column(name="zvalue", type="text", nullable=true)
     */
    private $zvalue;

    /**
     * @var string
     *
     * @ORM\Column(name="zoperation", type="text", nullable=true)
     */
    private $zoperation;


    //************************************************************************

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

 


    /**
     * Set zlist
     *
     * @param string $zlist
     * @return MozFilter
     */
    public function setZlist($zlist)
    {
        $this->zlist = $zlist;

        return $this;
    }

    /**
     * Get zlist
     *
     * @return string 
     */
    public function getZlist()
    {
        return $this->zlist;
    }

    /**
     * Set zcolumn
     *
     * @param string $zcolumn
     * @return MozFilter
     */
    public function setZcolumn($zcolumn)
    {
        $this->zcolumn = $zcolumn;

        return $this;
    }

    /**
     * Get zcolumn
     *
     * @return string 
     */
    public function getZcolumn()
    {
        return $this->zcolumn;
    }

    /**
     * Set zvalue
     *
     * @param string $zvalue
     * @return MozFilter
     */
    public function setZvalue($zvalue)
    {
        $this->zvalue = $zvalue;

        return $this;
    }

    /**
     * Get zvalue
     *
     * @return string 
     */
    public function getZvalue()
    {
        return $this->zvalue;
    }

    /**
     * Set zoperation
     *
     * @param string $zoperation
     * @return MozFilter
     */
    public function setZoperation($zoperation)
    {
        $this->zoperation = $zoperation;

        return $this;
    }

    /**
     * Get zoperation
     *
     * @return string 
     */
    public function getZoperation()
    {
        return $this->zoperation;
    }
}
