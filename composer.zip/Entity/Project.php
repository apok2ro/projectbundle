<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Project
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ProjectRepository")
 */
class Project
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="text", nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text", nullable=true)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="object", type="text", nullable=true)
     */
    private $object;
	
		
	/**
     * @var string
     *
     * @ORM\Column(name="latitude", type="text", nullable=true)
     */
    private $latitute;
	
		
	/**
     * @var string
     *
     * @ORM\Column(name="longitude", type="text", nullable=true)
     */
    private $longitude;


    /**
     * @var boolean
     *
     * @ORM\Column(name="humanitary", type="boolean", nullable=true)
     */
    private $humanitary;

    /**
     * @var datetime
     *
     * @ORM\Column(name="updateAt", type="datetime", nullable=true)
     */
    private $updateAt;
	
	/**
     * @var datetime
     *
     * @ORM\Column(name="createdAt", type="datetime", nullable=true)
     */
    private $createdAt;
	
	/**
     * @var date
     *
     * @ORM\Column(name="startdate", type="text", nullable=true)
     */
    private $startdate;
	
	/**
     * @var date
     *
     * @ORM\Column(name="enddate", type="text", nullable=true)
     */
    private $enddate;

    /**
     * @var boolean
     *
     * @ORM\Column(name="draft", type="boolean", nullable=true)
     */
    private $draft;





    /**
     * @var string
     *
     * @ORM\Column(name="switch", type="text", nullable=true)
     */
    private $switch;

	/**
     * @var integer
     *
     * @ORM\Column(name="cost", type="integer", nullable=true)
     */
    private $cost;
	
	
    /**
     * @var string
     *
     * @ORM\Column(name="result", type="text", nullable=true)
     */
    private $result;
	

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\State", inversedBy="projects")
     * @ORM\JoinColumn(nullable = true)
     */
    private $state;// a �limin�

    /**
     * @ORM\ManyToMany(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     */
    private $onBudget;


    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\OrganisationRole", mappedBy="project",cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $mins;
	
		
	/**
     * @ORM\ManyToMany(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     */
    private $statuts;


	/**
     * @ORM\ManyToMany(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     */
    private $levels;


	 /**
     * @ORM\ManyToMany(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     */
    private $fundingSource;
	
	 /**
     * @ORM\ManyToMany(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     */
    private $implementation;


	
	/**
     * @ORM\ManyToMany(targetEntity="Moz\ProjectBundle\Entity\CategoryValues")
     * @ORM\JoinColumn(nullable = true)
     */
    private $bv;


 
    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Funding", inversedBy="projects")
     * @ORM\JoinColumn(nullable = true)
     */
    private $funding;// � �limin�



    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\InternalId", mappedBy="project",cascade={"persist"})
     */
    private $keys;


    /**
     * @ORM\OneToOne(targetEntity="Moz\ProjectBundle\Entity\Planification", cascade={"persist"})
	 * @ORM\JoinColumn(nullable = true)
     */
    private $planification;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\Localisation", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $locations;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\ExecutionLevel", inversedBy="execLevel")
     * @ORM\JoinColumn(nullable = true)
     */
    private $execLevel;// � �liminier



    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectProgram", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $programs;


    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectProgram", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $programs1;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectProgram", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $programs2;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectSector", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $sectors;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectSector", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $sectors2;

    /**
     * @var string
     *
     * @ORM\Column(name="equalopportunity", type="text", nullable=true)
     */
    private $opportunite;

    /**
     * @var string
     *
     * @ORM\Column(name="environnement", type="text", nullable=true)
     */
    private $environnement;

    /**
     * @var string
     *
     * @ORM\Column(name="emploi", type="text", nullable=true)
     */
    private $emploi;



    /**
     * @var string
     *
     * @ORM\Column(name="emploif", type="text", nullable=true)
     */
    private $emploif;


    /**
     * @var string
     *
     * @ORM\Column(name="comp", type="text", nullable=true)
     */
    private $comp;


    /**
     * @var string
     *
     * @ORM\Column(name="obs", type="text", nullable=true)
     */
    private $obs;
	
	/**
     * @ORM\ManyToOne(targetEntity="Webkul\UVDesk\CoreFrameworkBundle\Entity\User")
     * @ORM\JoinColumn(nullable = true)
     */
    private $user;
	
		
	/**
     * @ORM\ManyToOne(targetEntity="Webkul\UVDesk\CoreFrameworkBundle\Entity\User")
     * @ORM\JoinColumn(nullable = true)
     */
    private $creator;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\Moz\AdminBundle\Entity\Workspace")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $team;





    /**
     * @ORM\OneToOne(targetEntity="Moz\ProjectBundle\Entity\FundingAmount", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $amount;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\FundingBase", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $finance;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectComponent", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $components;


    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\OrganisationRole", mappedBy="$executionAgencies", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $executionAgencies;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\OrganisationRole", mappedBy="$implementingAgencies", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $implementingAgencies;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\OrganisationRole", mappedBy="$beneficiaryAgencies", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $beneficiaryAgencies;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\OrganisationRole", mappedBy="$contractingAgencies", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $contractingAgencies;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\OrganisationRole", mappedBy="$regionalGroups", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $regionalGroups;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\OrganisationRole", mappedBy="$sectorialGroups", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $sectorialGroups;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\Issue", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $issues;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\RegionalObs", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $observations;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectContact", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $contacts;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectContact", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $econtacts;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectContract", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $contracts;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectIndicator", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $indicators;

    /**
     * @ORM\OneToMany(targetEntity="Moz\ProjectBundle\Entity\RegionalObs", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $sectorialobs;

    /**
     * @ORM\oneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectDocument", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $documents;

    /**
     * @ORM\oneToMany(targetEntity="Moz\ProjectBundle\Entity\ProjectDocument", mappedBy="project", cascade={"persist"})
     * @ORM\JoinColumn(nullable = true)
     */
    private $links;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Project
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Project
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }
	
	/**
     * Set id
     *
     * @param integer $id
     * @return Project
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }
	

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set object
     *
     * @param string $object
     * @return Project
     */
    public function setObject($object)
    {
        $this->object = $object;

        return $this;
    }

    /**
     * Get object
     *
     * @return string 
     */
    public function getObject()
    {
        return $this->object;
    }

    /**
     * Set humanitary
     *
     * @param boolean $humanitary
     * @return Project
     */
    public function setHumanitary($humanitary)
    {
        $this->humanitary = $humanitary;

        return $this;
    }

    /**
     * Get humanitary
     *
     * @return boolean 
     */
    public function getHumanitary()
    {
        return $this->humanitary;
    }

 
    /**
     * Set draft
     *
     * @param boolean $draft
     * @return Project
     */
    public function setDraft($draft)
    {
        $this->draft = $draft;

        return $this;
    }

    /**
     * Get draft
     *
     * @return boolean 
     */
    public function getDraft()
    {
        return $this->draft;
    }

    /**
     * Set updateAt
     *
     * @param \DateTime $updateAt
     * @return Project
     */
    public function setUpdateAt($updateAt)
    {
        $this->updateAt = $updateAt;

        return $this;
    }

    /**
     * Get updateAt
     *
     * @return \DateTime 
     */
    public function getUpdateAt()
    {
        return $this->updateAt;
    }

    /**
     * Set switch
     *
     * @param string $switch
     * @return Project
     */
    public function setSwitch($switch)
    {
        $this->switch = $switch;

        return $this;
    }

    /**
     * Get switch
     *
     * @return string 
     */
    public function getSwitch()
    {
        return $this->switch;
    }

    /**
     * Set budget
     *
     * @param boolean $budget
     * @return Project
     */
    public function setBudget($budget)
    {
        $this->budget = $budget;

        return $this;
    }

    /**
     * Get budget
     *
     * @return boolean 
     */
    public function getBudget()
    {
        return $this->budget;
    }

    /**
     * Set state
     *
     * @param \Moz\ProjectBundle\Entity\State $state
     * @return Project
     */
    public function setState(\Moz\ProjectBundle\Entity\State $state = null)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return \Moz\ProjectBundle\Entity\State 
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set funding
     *
     * @param \Moz\ProjectBundle\Entity\Funding $funding
     * @return Project
     */
    public function setFunding(\Moz\ProjectBundle\Entity\Funding $funding = null)
    {
        $this->funding = $funding;

        return $this;
    }

    /**
     * Get funding
     *
     * @return \Moz\ProjectBundle\Entity\Funding 
     */
    public function getFunding()
    {
        return $this->funding;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->keys = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add keys
     *
     * @param \Moz\ProjectBundle\Entity\InternalId $keys
     * @return Project
     */
    public function addKey(\Moz\ProjectBundle\Entity\InternalId $keys)
    {
        $keys->setProject($this);
        $this->keys[] = $keys;
        return $this;
    }

    /**
     * Remove keys
     *
     * @param \Moz\ProjectBundle\Entity\InternalId $keys
     */
    public function removeKey(\Moz\ProjectBundle\Entity\InternalId $keys)
    {
        $this->keys->removeElement($keys);
    }

    /**
     * Get keys
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getKeys()
    {
        return $this->keys;
    }

    /**
     * Set planification
     *
     * @param \Moz\ProjectBundle\Entity\Planification $planification
     * @return Project
     */
    public function setPlanification(\Moz\ProjectBundle\Entity\Planification $planification = null)
    {
        $this->planification = $planification;

        return $this;
    }

    /**
     * Get planification
     *
     * @return \Moz\ProjectBundle\Entity\Planification 
     */
    public function getPlanification()
    {
        return $this->planification;
    }

    /**
     * Add locations
     *
     * @param \Moz\ProjectBundle\Entity\Localisation $locations
     * @return Project
     */
    public function addLocation(\Moz\ProjectBundle\Entity\Localisation $locations)
    {
        $locations->setProject($this);
        $this->locations[] = $locations;

        return $this;
    }

    /**
     * Remove locations
     *
     * @param \Moz\ProjectBundle\Entity\Localisation $locations
     */
    public function removeLocation(\Moz\ProjectBundle\Entity\Localisation $locations)
    {
        $this->locations->removeElement($locations);
    }

    /**
     * Get locations
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getLocations()
    {
        return $this->locations;
    }

    /**
     * Set execLevel
     *
     * @param \Moz\ProjectBundle\Entity\ExecutionLevel $execLevel
     * @return Project
     */
    public function setExecLevel(\Moz\ProjectBundle\Entity\ExecutionLevel $execLevel = null)
    {
        $this->execLevel = $execLevel;

        return $this;
    }

    /**
     * Get execLevel
     *
     * @return \Moz\ProjectBundle\Entity\ExecutionLevel 
     */
    public function getExecLevel()
    {
        return $this->execLevel;
    }

    /**
     * Add programs
     *
     * @param \Moz\ProjectBundle\Entity\ProjectProgram $programs
     * @return Project
     */
    public function addProgram(\Moz\ProjectBundle\Entity\ProjectProgram $programs)
    {
        $programs->setProject($this);
        $this->programs[] = $programs;

        return $this;
    }

    /**
     * Remove programs
     *
     * @param \Moz\ProjectBundle\Entity\ProjectProgram $programs
     */
    public function removeProgram(\Moz\ProjectBundle\Entity\ProjectProgram $programs)
    {
        $this->programs->removeElement($programs);
    }

    /**
     * Get programs
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPrograms()
    {
        return $this->programs;
    }

    /**
     * Add programs1
     *
     * @param \Moz\ProjectBundle\Entity\ProjectProgram $programs1
     * @return Project
     */
    public function addPrograms1(\Moz\ProjectBundle\Entity\ProjectProgram $programs1)
    {
        $programs1->setProject($this);
        $this->programs1[] = $programs1;

        return $this;
    }

    /**
     * Remove programs1
     *
     * @param \Moz\ProjectBundle\Entity\ProjectProgram $programs1
     */
    public function removePrograms1(\Moz\ProjectBundle\Entity\ProjectProgram $programs1)
    {
        $this->programs1->removeElement($programs1);
    }

    /**
     * Get programs1
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPrograms1()
    {
        return $this->programs1;
    }

    /**
     * Add programs2
     *
     * @param \Moz\ProjectBundle\Entity\ProjectProgram $programs2
     * @return Project
     */
    public function addPrograms2(\Moz\ProjectBundle\Entity\ProjectProgram $programs2)
    {
        $programs2->setProject($this);
        $this->programs2[] = $programs2;

        return $this;
    }

    /**
     * Remove programs2
     *
     * @param \Moz\ProjectBundle\Entity\ProjectProgram $programs2
     */
    public function removePrograms2(\Moz\ProjectBundle\Entity\ProjectProgram $programs2)
    {
        $this->programs2->removeElement($programs2);
    }

    /**
     * Get programs2
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPrograms2()
    {
        return $this->programs2;
    }

    /**
     * Add sectors
     *
     * @param \Moz\ProjectBundle\Entity\ProjectSector $sectors
     * @return Project
     */
    public function addSector(\Moz\ProjectBundle\Entity\ProjectSector $sectors)
    {
        $sectors->setProject($this);
        $this->sectors[] = $sectors;

        return $this;
    }

    /**
     * Remove sectors
     *
     * @param \Moz\ProjectBundle\Entity\ProjectSector $sectors
     */
    public function removeSector(\Moz\ProjectBundle\Entity\ProjectSector $sectors)
    {
        $this->sectors->removeElement($sectors);
    }

    /**
     * Get sectors
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSectors()
    {
        return $this->sectors;
    }

    /**
     * Add sectors2
     *
     * @param \Moz\ProjectBundle\Entity\ProjectSector $sectors2
     * @return Project
     */
    public function addSectors2(\Moz\ProjectBundle\Entity\ProjectSector $sectors2)
    {
        $sectors2->setProject($this);
        $this->sectors2[] = $sectors2;

        return $this;
    }

    /**
     * Remove sectors2
     *
     * @param \Moz\ProjectBundle\Entity\ProjectSector $sectors2
     */
    public function removeSectors2(\Moz\ProjectBundle\Entity\ProjectSector $sectors2)
    {
        $this->sectors2->removeElement($sectors2);
    }

    /**
     * Get sectors2
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSectors2()
    {
        return $this->sectors2;
    }




    /**
     * Add executionAgencies
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $executionAgencies
     * @return Project
     */
    public function addExecutionAgency(\Moz\ProjectBundle\Entity\OrganisationRole $executionAgencies)
    {
        $executionAgencies->setProject($this);
        $this->executionAgencies[] = $executionAgencies;

        return $this;
    }

    /**
     * Remove executionAgencies
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $executionAgencies
     */
    public function removeExecutionAgency(\Moz\ProjectBundle\Entity\OrganisationRole $executionAgencies)
    {
        $this->executionAgencies->removeElement($executionAgencies);
    }

    /**
     * Get executionAgencies
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getExecutionAgencies()
    {
        return $this->executionAgencies;
    }

    public function setExecutionAgencies(\Moz\ProjectBundle\Entity\Role $c)
    {
        $this->executionAgencies[] = $c;
        return $this;
    }

    /**
     * Add implementingAgencies
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $implementingAgencies
     * @return Project
     */
    public function addImplementingAgency(\Moz\ProjectBundle\Entity\OrganisationRole $implementingAgencies)
    {
        $implementingAgencies->setProject($this);
        $this->implementingAgencies[] = $implementingAgencies;

        return $this;
    }

    /**
     * Remove implementingAgencies
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $implementingAgencies
     */
    public function removeImplementingAgency(\Moz\ProjectBundle\Entity\OrganisationRole $implementingAgencies)
    {
        $this->implementingAgencies->removeElement($implementingAgencies);
    }

    /**
     * Get implementingAgencies
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getImplementingAgencies()
    {
        return $this->implementingAgencies;
    }

    public function setImplementingAgencies(\Moz\ProjectBundle\Entity\Role $c)
    {
        $this->implementingAgencies[] = $c;
        return $this;
    }
    /**
     * Add beneficiaryAgencies
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $beneficiaryAgencies
     * @return Project
     */
    public function addBeneficiaryAgency(\Moz\ProjectBundle\Entity\OrganisationRole $beneficiaryAgencies)
    {
        $beneficiaryAgencies->setProject($this);
        $this->beneficiaryAgencies[] = $beneficiaryAgencies;

        return $this;
    }

    /**
     * Remove beneficiaryAgencies
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $beneficiaryAgencies
     */
    public function removeBeneficiaryAgency(\Moz\ProjectBundle\Entity\OrganisationRole $beneficiaryAgencies)
    {
        $this->beneficiaryAgencies->removeElement($beneficiaryAgencies);
    }

    /**
     * Get beneficiaryAgencies
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getBeneficiaryAgencies()
    {
        return $this->beneficiaryAgencies;
    }

    public function setBeneficiaryAgencies(\Moz\ProjectBundle\Entity\Role $c)
    {
        $this->beneficiaryAgencies[] = $c;
        return $this;
    }

    /**
     * Add contractingAgencies
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $contractingAgencies
     * @return Project
     */
    public function addContractingAgency(\Moz\ProjectBundle\Entity\OrganisationRole $contractingAgencies)
    {
        $contractingAgencies->setProject($this);
        $this->contractingAgencies[] = $contractingAgencies;

        return $this;
    }

    /**
     * Remove contractingAgencies
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $contractingAgencies
     */
    public function removeContractingAgency(\Moz\ProjectBundle\Entity\OrganisationRole $contractingAgencies)
    {
        $this->contractingAgencies->removeElement($contractingAgencies);
    }

    /**
     * Get contractingAgencies
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getContractingAgencies()
    {
        return $this->contractingAgencies;
    }


    public function setContractingAgencies(\Moz\ProjectBundle\Entity\Role $c)
    {
        $this->contractingAgencies[] = $c;
        return $this;
    }

    /**
     * Add regionalGroups
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $regionalGroups
     * @return Project
     */
    public function addRegionalGroup(\Moz\ProjectBundle\Entity\OrganisationRole $regionalGroups)
    {
        $regionalGroups->setProject($this);
        $this->regionalGroups[] = $regionalGroups;

        return $this;
    }

    /**
     * Remove regionalGroups
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $regionalGroups
     */
    public function removeRegionalGroup(\Moz\ProjectBundle\Entity\OrganisationRole $regionalGroups)
    {
        $this->regionalGroups->removeElement($regionalGroups);
    }

    /**
     * Get regionalGroups
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getRegionalGroups()
    {
        return $this->regionalGroups;
    }

    public function setRegionalGroups(\Moz\ProjectBundle\Entity\Role $c)
    {
        $this->regionalGroups[] = $c;
        return $this;
    }

    /**
     * Add sectorialGroups
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $sectorialGroups
     * @return Project
     */
    public function addSectorialGroup(\Moz\ProjectBundle\Entity\OrganisationRole $sectorialGroups)
    {
        $sectorialGroups->setProject($this);
        $this->sectorialGroups[] = $sectorialGroups;

        return $this;
    }

    /**
     * Remove sectorialGroups
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $sectorialGroups
     */
    public function removeSectorialGroup(\Moz\ProjectBundle\Entity\OrganisationRole $sectorialGroups)
    {
        $this->sectorialGroups->removeElement($sectorialGroups);
    }

    /**
     * Get sectorialGroups
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSectorialGroups()
    {
        return $this->sectorialGroups;
    }

    public function setSectorialGroups(\Moz\ProjectBundle\Entity\Role $c)
    {
        $this->sectorialGroups[] = $c;
        return $this;
    }



    /**
     * Set opportunite
     *
     * @param string $opportunite
     * @return Project
     */
    public function setOpportunite($opportunite)
    {
        $this->opportunite = $opportunite;

        return $this;
    }

    /**
     * Get opportunite
     *
     * @return string 
     */
    public function getOpportunite()
    {
        return $this->opportunite;
    }

    /**
     * Set environnement
     *
     * @param string $environnement
     * @return Project
     */
    public function setEnvironnement($environnement)
    {
        $this->environnement = $environnement;

        return $this;
    }

    /**
     * Get environnement
     *
     * @return string 
     */
    public function getEnvironnement()
    {
        return $this->environnement;
    }

    /**
     * Set mins
     *
     * @param string $mins
     * @return Project
     */
    public function setMins($mins)
    {
        $this->mins = $mins;

        return $this;
    }

    

    


    
    /**
     * Add finance
     *
     * @param \Moz\ProjectBundle\Entity\FundingBase $finance
     * @return Project
     */
    public function addFinance(\Moz\ProjectBundle\Entity\FundingBase $finance)
    {
        $finance->setProject($this);
        $this->finance[] = $finance;

        return $this;
    }

    /**
     * Remove finance
     *
     * @param \Moz\ProjectBundle\Entity\FundingBase $finance
     */
    public function removeFinance(\Moz\ProjectBundle\Entity\FundingBase $finance)
    {
        $this->finance->removeElement($finance);
    }

    /**
     * Get finance
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getFinance()
    {
        return $this->finance;
    }



    /**
     * Add components
     *
     * @param \Moz\ProjectBundle\Entity\ProjectComponent $components
     * @return Project
     */
    public function addComponent(\Moz\ProjectBundle\Entity\ProjectComponent $components)
    {
        $components->setProject($this);
        $this->components[] = $components;

        return $this;
    }

    /**
     * Remove components
     *
     * @param \Moz\ProjectBundle\Entity\ProjectComponent $components
     */
    public function removeComponent(\Moz\ProjectBundle\Entity\ProjectComponent $components)
    {
        $this->components->removeElement($components);
    }

    /**
     * Get components
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getComponents()
    {
        return $this->components;
    }

    /**
     * Add issues
     *
     * @param \Moz\ProjectBundle\Entity\Issue $issues
     * @return Project
     */
    public function addIssue(\Moz\ProjectBundle\Entity\Issue $issues)
    {
        $issues->setProject($this);
        $this->issues[] = $issues;

        return $this;
    }

    /**
     * Remove issues
     *
     * @param \Moz\ProjectBundle\Entity\Issue $issues
     */
    public function removeIssue(\Moz\ProjectBundle\Entity\Issue $issues)
    {
        $this->issues->removeElement($issues);
    }

    /**
     * Get issues
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getIssues()
    {
        return $this->issues;
    }

    /**
     * Add observations
     *
     * @param \Moz\ProjectBundle\Entity\RegionalObs $observations
     * @return Project
     */
    public function addObservation(\Moz\ProjectBundle\Entity\RegionalObs $observations)
    {
        $observations->setProject($this);
        $this->observations[] = $observations;

        return $this;
    }

    /**
     * Remove observations
     *
     * @param \Moz\ProjectBundle\Entity\RegionalObs $observations
     */
    public function removeObservation(\Moz\ProjectBundle\Entity\RegionalObs $observations)
    {
        $this->observations->removeElement($observations);
    }

    /**
     * Get observations
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getObservations()
    {
        return $this->observations;
    }

    /**
     * Add contacts
     *
     * @param \Moz\ProjectBundle\Entity\ProjectContact $contacts
     * @return Project
     */
    public function addContact(\Moz\ProjectBundle\Entity\ProjectContact $contacts)
    {
        $contacts->setProject($this);
        $this->contacts[] = $contacts;

        return $this;
    }

    /**
     * Remove contacts
     *
     * @param \Moz\ProjectBundle\Entity\ProjectContact $contacts
     */
    public function removeContact(\Moz\ProjectBundle\Entity\ProjectContact $contacts)
    {
        $this->contacts->removeElement($contacts);
    }

    /**
     * Get contacts
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getContacts()
    {
        return $this->contacts;
    }

    /**
     * Add econtacts
     *
     * @param \Moz\ProjectBundle\Entity\ProjectContact $econtacts
     * @return Project
     */
    public function addEcontact(\Moz\ProjectBundle\Entity\ProjectContact $econtacts)
    {
        $econtacts->setProject($this);
        $this->econtacts[] = $econtacts;

        return $this;
    }

    /**
     * Remove econtacts
     *
     * @param \Moz\ProjectBundle\Entity\ProjectContact $econtacts
     */
    public function removeEcontact(\Moz\ProjectBundle\Entity\ProjectContact $econtacts)
    {
        $this->econtacts->removeElement($econtacts);
    }

    /**
     * Get econtacts
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getEcontacts()
    {
        return $this->econtacts;
    }

    
    /**
     * Add indicators
     *
     * @param \Moz\ProjectBundle\Entity\ProjectIndicator $indicators
     * @return Project
     */
    public function addIndicator(\Moz\ProjectBundle\Entity\ProjectIndicator $indicators)
    {
        $indicators->setProject($this);
        $this->indicators[] = $indicators;

        return $this;
    }

    /**
     * Remove indicators
     *
     * @param \Moz\ProjectBundle\Entity\ProjectIndicator $indicators
     */
    public function removeIndicator(\Moz\ProjectBundle\Entity\ProjectIndicator $indicators)
    {
        $this->indicators->removeElement($indicators);
    }

    /**
     * Get indicators
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getIndicators()
    {
        return $this->indicators;
    }

    /**
     * Add sectorialobs
     *
     * @param \Moz\ProjectBundle\Entity\RegionalObs $sectorialobs
     * @return Project
     */
    public function addSectorialob(\Moz\ProjectBundle\Entity\RegionalObs $sectorialobs)
    {
        $sectorialobs->setProject($this);
        $this->sectorialobs[] = $sectorialobs;

        return $this;
    }

    /**
     * Remove sectorialobs
     *
     * @param \Moz\ProjectBundle\Entity\RegionalObs $sectorialobs
     */
    public function removeSectorialob(\Moz\ProjectBundle\Entity\RegionalObs $sectorialobs)
    {
        $this->sectorialobs->removeElement($sectorialobs);
    }

    /**
     * Get sectorialobs
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSectorialobs()
    {
        return $this->sectorialobs;
    }



    /**
     * Add documents
     *
     * @param \Moz\ProjectBundle\Entity\ProjectDocument $documents
     * @return Project
     */
    public function addDocument(\Moz\ProjectBundle\Entity\ProjectDocument $documents)
    {
        $documents->setProject($this);
        $this->documents[] = $documents;

        return $this;
    }

    /**
     * Remove documents
     *
     * @param \Moz\ProjectBundle\Entity\ProjectDocument $documents
     */
    public function removeDocument(\Moz\ProjectBundle\Entity\ProjectDocument $documents)
    {
        $this->documents->removeElement($documents);
    }

    /**
     * Get documents
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getDocuments()
    {
        return $this->documents;
    }

    /**
     * Add links
     *
     * @param \Moz\ProjectBundle\Entity\ProjectDocument $links
     * @return Project
     */
    public function addLink(\Moz\ProjectBundle\Entity\ProjectDocument $links)
    {
        $links->setProject($this);
        $this->links[] = $links;

        return $this;
    }

    /**
     * Remove links
     *
     * @param \Moz\ProjectBundle\Entity\ProjectDocument $links
     */
    public function removeLink(\Moz\ProjectBundle\Entity\ProjectDocument $links)
    {
        $this->links->removeElement($links);
    }

    /**
     * Get links
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getLinks()
    {
        return $this->links;
    }






    /**
     * Add statuts
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $statuts
     * @return Project
     */
    public function addStatut(\Moz\ProjectBundle\Entity\CategoryValues $statuts)
    {
        $this->statuts[] = $statuts;

        return $this;
    }

    /**
     * Remove statuts
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $statuts
     */
    public function removeStatut(\Moz\ProjectBundle\Entity\CategoryValues $statuts)
    {
        $this->statuts->removeElement($statuts);
    }

    /**
     * Get statuts
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getStatuts()
    {
        return $this->statuts;
    }

    public function setStatuts(\Moz\ProjectBundle\Entity\CategoryValues $statuts){
        $this->statuts[] = $statuts;

        return $this;
    }

    /**
     * Add onBudget
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $onBudget
     * @return Project
     */
    public function addOnBudget(\Moz\ProjectBundle\Entity\CategoryValues $onBudget)
    {
        $this->onBudget[] = $onBudget;

        return $this;
    }

    /**
     * Remove onBudget
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $onBudget
     */
    public function removeOnBudget(\Moz\ProjectBundle\Entity\CategoryValues $onBudget)
    {
        $this->onBudget->removeElement($onBudget);
    }

    /**
     * Get onBudget
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getOnBudget()
    {
        return $this->onBudget;
    }

    public function setOnBudget(\Moz\ProjectBundle\Entity\CategoryValues $onBudget)
    {
        $this->onBudget[] = $onBudget;
        return $this;
    }

    /**
     * Add fundingSource
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $fundingSource
     * @return Project
     */
    public function addFundingSource(\Moz\ProjectBundle\Entity\CategoryValues $fundingSource)
    {
        $this->fundingSource[] = $fundingSource;

        return $this;
    }

    /**
     * Remove fundingSource
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $fundingSource
     */
    public function removeFundingSource(\Moz\ProjectBundle\Entity\CategoryValues $fundingSource)
    {
        $this->fundingSource->removeElement($fundingSource);
    }

    /**
     * Get fundingSource
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getFundingSource()
    {
        return $this->fundingSource;
    }

    /**
     * Add implementation
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $implementation
     * @return Project
     */
    public function addImplementation(\Moz\ProjectBundle\Entity\CategoryValues $implementation)
    {
        $this->implementation[] = $implementation;

        return $this;
    }

    /**
     * Remove implementation
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $implementation
     */
    public function removeImplementation(\Moz\ProjectBundle\Entity\CategoryValues $implementation)
    {
        $this->implementation->removeElement($implementation);
    }

    /**
     * Get implementation
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getImplementation()
    {
        return $this->implementation;
    }

    public function setImplementation(\Moz\ProjectBundle\Entity\CategoryValues $implementation)
    {
        $this->implementation[] = $implementation;
        return $this;
    }

    /**
     * Set emploi
     *
     * @param string $emploi
     * @return Project
     */
    public function setEmploi($emploi)
    {
        $this->emploi = $emploi;

        return $this;
    }

    /**
     * Get emploi
     *
     * @return string 
     */
    public function getEmploi()
    {
        return $this->emploi;
    }



    /**
     * Set amount
     *
     * @param \Moz\ProjectBundle\Entity\FundingAmount $amount
     * @return Project
     */
    public function setAmount(\Moz\ProjectBundle\Entity\FundingAmount $amount = null)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return \Moz\ProjectBundle\Entity\FundingAmount 
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Add contracts
     *
     * @param \Moz\ProjectBundle\Entity\ProjectContract $contracts
     * @return Project
     */
    public function addContract(\Moz\ProjectBundle\Entity\ProjectContract $contracts)
    {
        $contracts->setProject($this);
        $this->contracts[] = $contracts;

        return $this;
    }

    /**
     * Remove contracts
     *
     * @param \Moz\ProjectBundle\Entity\ProjectContract $contracts
     */
    public function removeContract(\Moz\ProjectBundle\Entity\ProjectContract $contracts)
    {
        $this->contracts->removeElement($contracts);
    }

    /**
     * Get contracts
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getContracts()
    {
        return $this->contracts;
    }

    /**
     * Add mins
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $mins
     * @return Project
     */
    public function addMin(\Moz\ProjectBundle\Entity\OrganisationRole $mins)
    {
        $mins->setProject($this);
        $this->mins[] = $mins;

        return $this;
    }

    /**
     * Remove mins
     *
     * @param \Moz\ProjectBundle\Entity\OrganisationRole $mins
     */
    public function removeMin(\Moz\ProjectBundle\Entity\OrganisationRole $mins)
    {
        $this->mins->removeElement($mins);
    }

    /**
     * Get mins
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMins()
    {
        return $this->mins;
    }

   
    /**
     * Set emploif
     *
     * @param string $emploif
     * @return Project
     */
    public function setEmploif($emploif)
    {
        $this->emploif = $emploif;

        return $this;
    }

    /**
     * Get emploif
     *
     * @return string 
     */
    public function getEmploif()
    {
        return $this->emploif;
    }

    /**
     * Set comp
     *
     * @param string $comp
     * @return Project
     */
    public function setComp($comp)
    {
        $this->comp = $comp;

        return $this;
    }

    /**
     * Get comp
     *
     * @return string 
     */
    public function getComp()
    {
        return $this->comp;
    }

    /**
     * Set obs
     *
     * @param string $obs
     * @return Project
     */
    public function setObs($obs)
    {
        $this->obs = $obs;

        return $this;
    }

    /**
     * Get obs
     *
     * @return string 
     */
    public function getObs()
    {
        return $this->obs;
    }

    /**
     * Set user
     *
     * @param \Webkul\UVDesk\CoreFrameworkBundle\Entity\User $user
     * @return Project
     */
    public function setUser(\Webkul\UVDesk\CoreFrameworkBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \Webkul\UVDesk\CoreFrameworkBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set team
     *
     * @param \Moz\Moz\AdminBundle\Entity\Workspace $team
     * @return Project
     */
    public function setTeam(\Moz\Moz\AdminBundle\Entity\Workspace $team = null)
    {
        $this->team = $team;

        return $this;
    }

    /**
     * Get team
     *
     * @return \Moz\Moz\AdminBundle\Entity\Workspace 
     */
    public function getTeam()
    {
        return $this->team;
    }


    /**
     * Add levels
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $levels
     * @return Project
     */
    public function addLevel(\Moz\ProjectBundle\Entity\CategoryValues $levels)
    {
        $this->levels[] = $levels;

        return $this;
    }

    /**
     * Remove levels
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $levels
     */
    public function removeLevel(\Moz\ProjectBundle\Entity\CategoryValues $levels)
    {
        $this->levels->removeElement($levels);
    }

    /**
     * Get levels
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getLevels()
    {
        return $this->levels;
    }
	
	
    public function setLevels(\Moz\ProjectBundle\Entity\CategoryValues $levels){
        $this->levels[] = $levels;

        return $this;
    }

    /**
     * Add bv
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $bv
     * @return Project
     */
    public function addBv(\Moz\ProjectBundle\Entity\CategoryValues $bv)
    {
        $this->bv[] = $bv;

        return $this;
    }

    /**
     * Remove bv
     *
     * @param \Moz\ProjectBundle\Entity\CategoryValues $bv
     */
    public function removeBv(\Moz\ProjectBundle\Entity\CategoryValues $bv)
    {
        $this->bv->removeElement($bv);
    }

    /**
     * Get bv
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getBv()
    {
        return $this->bv;
    }

    /**
     * Set cost
     *
     * @param integer $cost
     * @return Project
     */
    public function setCost($cost)
    {
        $this->cost = $cost;

        return $this;
    }

    /**
     * Get cost
     *
     * @return integer 
     */
    public function getCost()
    {
        return $this->cost;
    }

    /**
     * Set result
     *
     * @param string $result
     * @return Project
     */
    public function setResult($result)
    {
        $this->result = $result;

        return $this;
    }

    /**
     * Get result
     *
     * @return string 
     */
    public function getResult()
    {
        return $this->result;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return Project
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

   
    /**
     * Set creator
     *
     * @param \Webkul\UVDesk\CoreFrameworkBundle\Entity\User $creator
     * @return Project
     */
    public function setCreator(\Webkul\UVDesk\CoreFrameworkBundle\Entity\User $creator = null)
    {
        $this->creator = $creator;

        return $this;
    }

    /**
     * Get creator
     *
     * @return \Webkul\UVDesk\CoreFrameworkBundle\Entity\User 
     */
    public function getCreator()
    {
        return $this->creator;
    }

    /**
     * Set latitute
     *
     * @param string $latitute
     * @return Project
     */
    public function setLatitute($latitute)
    {
        $this->latitute = $latitute;

        return $this;
    }

    /**
     * Get latitute
     *
     * @return string 
     */
    public function getLatitute()
    {
        return $this->latitute;
    }

    /**
     * Set longitude
     *
     * @param string $longitude
     * @return Project
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    /**
     * Get longitude
     *
     * @return string 
     */
    public function getLongitude()
    {
        return $this->longitude;
    }

  

    /**
     * Set startdate
     *
     * @param string $startdate
     * @return Project
     */
    public function setStartdate($startdate)
    {
        $this->startdate = $startdate;

        return $this;
    }

    /**
     * Get startdate
     *
     * @return string 
     */
    public function getStartdate()
    {
        return $this->startdate;
    }

    /**
     * Set enddate
     *
     * @param string $enddate
     * @return Project
     */
    public function setEnddate($enddate)
    {
        $this->enddate = $enddate;

        return $this;
    }

    /**
     * Get enddate
     *
     * @return string 
     */
    public function getEnddate()
    {
        return $this->enddate;
    }
}
