<?php

namespace Moz\ProjectBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ContractOrganisation
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Moz\ProjectBundle\Entity\ContractOrganisationRepository")
 */
class ContractOrganisation
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Contract")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $contract;

    /**
     * @ORM\ManyToOne(targetEntity="Moz\ProjectBundle\Entity\Organisation")
     * @ORM\JoinColumn(nullable = true)
     *
     */
    private $organisation;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set contract
     *
     * @param \Moz\ProjectBundle\Entity\Contract $contract
     * @return ContractOrganisation
     */
    public function setContract(\Moz\ProjectBundle\Entity\Contract $contract = null)
    {
        $this->contract = $contract;

        return $this;
    }

    /**
     * Get contract
     *
     * @return \Moz\ProjectBundle\Entity\Contract 
     */
    public function getContract()
    {
        return $this->contract;
    }

    /**
     * Set organisation
     *
     * @param \Moz\ProjectBundle\Entity\Organisation $organisation
     * @return ContractOrganisation
     */
    public function setOrganisation(\Moz\ProjectBundle\Entity\Organisation $organisation = null)
    {
        $this->organisation = $organisation;

        return $this;
    }

    /**
     * Get organisation
     *
     * @return \Moz\ProjectBundle\Entity\Organisation 
     */
    public function getOrganisation()
    {
        return $this->organisation;
    }
}
