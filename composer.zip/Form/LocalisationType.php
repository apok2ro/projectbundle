<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class LocalisationType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder

            ->add('location','entity',array(
                'label'=>'',
                'class'=>"MozProjectBundle:Location",
                'property'=>"fullname",
                'query_builder'=>function(\Moz\ProjectBundle\Entity\LocationRepository $r){
                    return $r->getValidLactions();
                },
                'multiple'=>false,
                'expanded'=>false,
                'empty_value'=>'Selectionnez une option'
                )
            )
            ->add('pourcentage',null,array('label'=>"Pourcentage", 'required' => false,'attr'=>array('style'=>"display:none;",'value'=>100, 'visible'=>false), 'label_attr'=>array('style'=>"display:none;",'visible'=>false)))
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\Localisation'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_localisation';
    }
}
