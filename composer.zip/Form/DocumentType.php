<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Moz\Moz\AdminBundle\Form\MediaSchemeType2;

class DocumentType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('title','text',array('label'=>'Titre', 'required'=>false))
            ->add('description','textarea',array('label'=>'Description', 'required'=>false))
            ->add('note','textarea',array('label'=>'Note', 'required'=>false))
            ->add('isLink','text',array('label_attr'=>array('style'=>'display:none'),
                'attr'=>array('style'=>'display:none', 'value'=>'0'), 'required'=>false
            ))
            ;
        $class=5;
        $builder
            ->add('type','entity',array(
                'label'=>"Type",
                'class'=>"MozProjectBundle:CategoryValues",
                'empty_value'=>"Selectionnez une Option",
                'property'=>"name",
                'required'=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                    return $r->getByClass($class);
                },
             )
            )

            ->add('media', new MediaSchemeType2())
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\Document'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_document';
    }
}
