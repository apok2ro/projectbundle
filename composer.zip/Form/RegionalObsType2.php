<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class RegionalObsType2 extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name','textarea',array('label'=>'observation'))
            ->add('date','text',array(
                    'label'=>'Date',
                    'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')
                )
            )
            ->add('measures','collection',array(
                    'type'=> new RegionalObsMeasureType(),
                    'allow_add'=> true,
                    'allow_delete' => true,
                    'label'=>'Mesures',
                )
            )
            ->add('source','text',array('attr'=>array('style'=>'display:none','value'=>'1'),
                    'label_attr'=>array('style'=>'display:none')

                )
            )
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\RegionalObs'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_regionalobs2';
    }
}
