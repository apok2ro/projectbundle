<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class OrganisationRoleType2 extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('role','entity',array(
                'label'=>'',
                'label_attr'=>array('style'=>"display:none;"),
                'class'=>"MozProjectBundle:Role",
                'property'=>"name",
                'attr'=>array('style'=>'display:none'),
                'query_builder'=>function(\Moz\ProjectBundle\Entity\RoleRepository $r){
            return $r->getExecutionAgencyRole();
        }
    ))
            ->add('organisation','entity',array(
                    'label'=>'',
                    'class'=>"MozProjectBundle:Organisation",
                    'property'=>"organisation"
                )
            )
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\OrganisationRole'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_organisationrole2';
    }
}
