<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ProjectCategoryValuesType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $class =$options['class'];
        $builder
            ->add('value', 'entity',array(
                'label'=>'',
                'label_attr'=>array('style'=>"display:none;"),
                'class'=>"MozProjectBundle:CategoryValues",
                'empty_value'=>"Aucun choix",
                'property'=>"name",
                'required'=>false,
                'expanded'=>$options['expanded'],
                'multiple'=>$options['multiple'],
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                    return $r->getByClass($class);
                },

            ))
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\ProjectCategoryValues',
            'class'=> '',
            'multiple'=> '',
            'expanded'=> '',
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_projectcategoryvalues';
    }
}
