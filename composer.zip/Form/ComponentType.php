<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ComponentType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('title','text', array('label'=>'tittre du composant','required'=>false))
            ->add('description','text', array('label'=>'description','required'=>false))
            ->add('type','entity',array(
                'label'=>"Type de composant",
                'class'=>"MozProjectBundle:ComponentType",
                'empty_value'=>"Selectionnez une Option",
                'property'=>"name",
                'required'=>false,
            ))
            ->add('commitments','collection',array(
                'label'=>'Engagements',
                'type'=> new ComponentFundingType(),
                'allow_add'=> true,
                'allow_delete'=>true,

            ))

            ->add('dibursements','collection',array(
                'label'=>'Décaissements',
                'type'=> new ComponentFundingType2(),
                'allow_add'=> true,
                'allow_delete'=>true,

            ))
            
            ->add('expanditures','collection',array(
                'label'=>'Dépenses',
                'type'=> new ComponentFundingType3(),
                'allow_add'=> true,
                'allow_delete'=>true,

            ))


        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\Component'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_component';
    }
}
