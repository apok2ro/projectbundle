<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class FundingBaseType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder

            ->add('organisation','entity',array(
                'label'=>'Organisation',
                'class'=>"MozProjectBundle:Organisation",
                'property'=>"organisation",
                'required'=>false
            ))
            ;
            $class= 11;
            $builder
            ->add('financingInstrument','entity',array(
                'label'=>"Instrument de financement",
                'class'=>"MozProjectBundle:CategoryValues",
                'empty_value'=>"Selectionnez une Option",
                'property'=>"name",
                'required'=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                    return $r->getByClass($class);
                },
              )
            )
            ;
            $class= 12;
            $builder
            ->add('typeOfAssistance','entity',array(
                    'label'=>"Type d'assistance",
                    'class'=>"MozProjectBundle:CategoryValues",
                    'empty_value'=>"Selectionnez une Option",
                    'property'=>"name",
                    'required'=>false,
                    'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                        return $r->getByClass($class);
                    },
                )
            )
            ->add('transaction','text',array('label'=>"Identifiant de la transaction",'required'=>false))
                ->add('commitments','collection',array(
                    'label'=>'Engagements',
                    'type'=> new FundingDetailType(),
                    'allow_add'=> true,
                    'allow_delete'=>true,

                ))
                ->add('dibursements','collection',array(
                    'label'=>'Décaissements',
                    'type'=> new FundingDetailType2(),
                    'allow_add'=> true,
                    'allow_delete'=>true,

                ))
                ->add('expanditures','collection',array(
                    'label'=>'Dépenses',
                    'type'=> new FundingDetailType3(),
                    'allow_add'=> true,
                    'allow_delete'=>true,

                ))


        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\FundingBase'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_fundingbase';
    }
}
