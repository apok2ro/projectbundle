<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ProjectSectorType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder

            ->add('sector','entity',array(
                'label'=>'',
                'label_attr'=>array('style'=>"display:none;"),
                'class'=>"MozProjectBundle:Sector",
                'empty_value'=>'Selectionez une option',
                'property'=>"name",
                'query_builder'=>function(\Moz\ProjectBundle\Entity\SectorRepository $r){
                    return $r->getPrimarySectors();
                    }
                 ))

            ->add('pourcentage','text',array('required' => false,'attr'=>array('style'=>"display:none;",'value'=>100), 'label_attr'=>array('style'=>"display:none;")))
            ->add('classification','text',array('attr'=>array('style'=>"display:none;",'value'=>1), 'label_attr'=>array('style'=>"display:none;"),))

        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\ProjectSector'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_projectsector';
    }
}
