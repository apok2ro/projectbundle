<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Moz\ProjectBundle\Form\ProjectFactFilter1Type;
class FactType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('organisation','entity',array(
                'label'=>'Agences donatrices',
                'class'=>"MozProjectBundle:Organisation",
                'property'=>"organisation",
                'multiple'=>true,
                'expanded'=>true,
                'required'=>false
            ))
            ->add('organisationGroup','entity',array(
                'label'=>'Groupes de donateurs',
                'class'=>"MozProjectBundle:OrganisationGroup",
                'property'=>"name",
                'multiple'=>true,
                'expanded'=>true,
                'required'=>false
            ))
			
            ->add('organisationType','entity',array(
                'label'=>'Types de Donateurs',
                'class'=>"MozProjectBundle:OrganisationType",
                'property'=>"name",
                'multiple'=>true,
                'expanded'=>true,
                'required'=>false
            ))
            
            ->add('implAgency','entity',array(
                'label'=>"Agences d'Implementations",
                'class'=>"MozProjectBundle:Organisation",
                'property'=>"organisation",
                'multiple'=>true,
                'expanded'=>true,
                'required'=>false
            ))
			
			
            ->add('execAgency','entity',array(
                'label'=>"Agences d'Executions",
                'class'=>"MozProjectBundle:Organisation",
                'property'=>"organisation",
                'multiple'=>true,
                'expanded'=>true,
                'required'=>false
            ))
			
            ->add('benAgency','entity',array(
                'label'=>'Agences Bénéficiaires',
                'class'=>"MozProjectBundle:Organisation",
                'property'=>"organisation",
                'multiple'=>true,
                'expanded'=>true,
                'required'=>false
            ))
			
            ->add('min','entity',array(
                'label'=>'Agences Responsables',
                'class'=>"MozProjectBundle:Organisation",
                'property'=>"organisation",
                'multiple'=>true,
                'expanded'=>true,
                'required'=>false
            ))
            
            ->add('principalSector','entity',array(
                'label'=>'Secteurs Principaux',
                'class'=>"MozProjectBundle:Sector",
                'multiple'=>true,
                'expanded'=>true,
                'property'=>"name",
                'query_builder'=>function(\Moz\ProjectBundle\Entity\SectorRepository $r){
                    return $r->getPrimarySectors();
                }
            ))
			
            ->add('secondarySector','entity',array(
                'label'=>'Secteurs Secondaires',
                'class'=>"MozProjectBundle:Sector",
                'multiple'=>true,
                'expanded'=>true,
                'property'=>"name",
                'query_builder'=>function(\Moz\ProjectBundle\Entity\SectorRepository $r){
                    return $r->getSecondarySectors();
                }
            ));
			
            $class= 11;
            $builder
                ->add('finInstrument','entity',array(
                        'label'=>"Instrument de Financement",
                        'class'=>"MozProjectBundle:CategoryValues",
                        'multiple'=>true,
                        'expanded'=>true,
                        'property'=>"name",
                        'required'=>false,
                        'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                            return $r->getByClass($class);
                        },
                    )
                )
            ;
            $class= 12;
            $builder
                ->add('TypeAssistance','entity',array(
                        'label'=>"Type d'Assistance",
                        'class'=>"MozProjectBundle:CategoryValues",
                        'multiple'=>true,
                        'expanded'=>true,
                        'property'=>"name",
                        'required'=>false,
                        'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                            return $r->getByClass($class);
                        },
                    )
                )

            ->add('status','entity',
                array('label'=>"Statut de l'Actiité",
                    'class'=>'MozProjectBundle:CategoryValues',
                    'property'=> 'name',
                    'expanded'=> true, 'multiple'=>true,"required"=>false,
                    'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r){
                        return $r->getByClass(6);
                    }
                ))
            ->add('bugdet','entity',array(
                'label'=>"Bugdet de l'Activité",
                'class'=>'MozProjectBundle:CategoryValues',
                'property'=> 'name',
                'expanded'=> true, 'multiple'=>true,"required"=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r){
                    return $r->getByClass(44);
                }
            ))
                ->add('region','entity',array(
                        'label'=>'Provinces',
                        'class'=>"MozProjectBundle:Location",
                        'property'=>"name",
                        'query_builder'=>function(\Moz\ProjectBundle\Entity\LocationRepository $r){
                            return $r->getValidRegions();
                        },
                        'multiple'=>true,
                        'expanded'=>true,
                    )
                )

            ->add('project',new ProjectFactFilter1Type(), array('label'=>'Recherche par mots clés'))
            ->add('project__',new ProjectFactFilter2Type(), array('label'=>'aide humanitaire'))
            ->add('project___',new ProjectFactFilter3Type(), array('label'=>'statut d\'approbation'))
            ->add('project____',new ProjectFactFilter4Type(), array('label'=>'date de debut effective'))
                ->add('program','entity',array(
                    'label'=>'Programme national',
                    'class'=>"MozProjectBundle:Program",
                    'multiple'=>true,
                    'expanded'=>true,
                    'property'=>"name",
                    'query_builder'=>function(\Moz\ProjectBundle\Entity\ProgramRepository $r){
                        return $r->getObjectivesPrograms();
                    }
                ))
                ->add('program_','entity',array(
                    'label'=>'Programme nationaux',
                    'class'=>"MozProjectBundle:Program",
                    'multiple'=>true,
                    'expanded'=>true,
                    'property'=>"name",
                    'query_builder'=>function(\Moz\ProjectBundle\Entity\ProgramRepository $r){
                        return $r->getNationalPrograms();
                    }
                ))
                ->add('program__','entity',array(
                    'label'=>'objectif de la planification nationale',
                    'class'=>"MozProjectBundle:Program",
                    'multiple'=>true,
                    'expanded'=>true,
                    'property'=>"name",
                    'query_builder'=>function(\Moz\ProjectBundle\Entity\ProgramRepository $r){
                        return $r->getSectorialPrograms();
                    }
                ))
            

        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\Fact'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_fact';
    }
}
