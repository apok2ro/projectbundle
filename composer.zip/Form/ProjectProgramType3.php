<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ProjectProgramType3 extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('program','entity',array(
                'label'=>'',
                'class'=>"MozProjectBundle:Program",
                'empty_value'=>'Selectionez une option',
                'property'=>"name",
                'query_builder'=>function(\Moz\ProjectBundle\Entity\ProgramRepository $r){
                    return $r->getNationalPrograms();
                }
            ))
            ->add('pourcentage',null,array('attr'=>array('disabled')))
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\ProjectProgram'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_projectprogram3';
    }
}
