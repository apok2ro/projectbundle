<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ContactType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $class= 39;
        $builder
            ->add('title','entity',array(
                'label'=>"Titre",
                'class'=>"MozProjectBundle:CategoryValues",
                'empty_value'=>"Selectionnez une Option",
                'property'=>"name",
                'required'=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                    return $r->getByClass($class);
                },
            ))
            ->add('name','text',array('label'=>'Nom', 'required'=>false,))
            ->add('lastname','text',array('label'=>'Prenom', 'required'=>false,))
            ->add('mails','collection',array(
                'label'=>"Adresses email",
                'type'=> new EmailPropertyType(),
                'allow_add'=> true,
                'allow_delete'=> true,
                'required'=>false,
            ))
            ->add('organisationname','text',array('label'=>"Nom de l'organisation", 'required'=>false,))
            ->add('function','text',array('label'=>'fonction', 'required'=>false,))
            ->add('officeaddress','textarea',array('label'=>'Adresse du Bureau', 'required'=>false,))
            ->add('phones','collection',array(
                'label'=>"Téléphones",
                'type'=> new ContactPropertyType(),
                'allow_add'=> true,
                'allow_delete'=> true,
                'required'=>false,

            ))
            ->add('faxs','collection',array(
                'label'=>"Fax",
                'type'=> new FaxPropertyType(),
                'allow_add'=> true,
                'allow_delete'=> true,
                'required'=>false,
            ))
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\Contact'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_contact';
    }
}
