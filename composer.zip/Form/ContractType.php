<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ContractType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name','text',array('label'=>'Numéro du contrat', 'required'=>false))
            ->add('description','text',array('label'=>'', 'required'=>false));
        $class=21;
        $builder
            ->add('category','entity',array(
                'label'=>"Type d'activité",
                'class'=>"MozProjectBundle:CategoryValues",
                'empty_value'=>"Selectionnez une Option",
                'property'=>"name",
                'required'=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                    return $r->getByClass($class);
                },
            ));
        $class=23;
        $builder
            ->add('type','entity',array(
                'label'=>"Type de contrat",
                'class'=>"MozProjectBundle:CategoryValues",
                'empty_value'=>"Selectionnez une Option",
                'property'=>"name",
                'required'=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                    return $r->getByClass($class);
                },
            ));
        $class=22;
        $builder
            ->add('startOfTendering','text',array('label'=>"Date de l'appel d'offre", 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))
            ->add('signatureOfContract','text',array('label'=>'Signature', 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))
            ->add('contractValidity','text',array('label'=>'Validité', 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))
            ->add('contractCompletion','text',array('label'=>'Fin', 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))
            ->add('orgName','text',array('label'=>'Nom du contractant', 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))
            ->add('status','entity',array(
                'label'=>"Statut",
                'class'=>"MozProjectBundle:CategoryValues",
                'empty_value'=>"Selectionnez une Option",
                'property'=>"name",
                'required'=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                    return $r->getByClass($class);
                },
            ))
            ->add('organisations','collection',
                array('type'=>new ContractOrganisationType(),
                    'label'=>'Organisations contractantes',
                    'allow_add'=>true,
                    'allow_delete'=>true, 'required'=>false
                ))
            ->add('totalValue','text',array('label'=>'Valeur totale', 'required'=>false))
            ->add('totalAmount','text',array('label'=>'Montant total', 'required'=>false))
            ->add('totalAmountCurrency','entity',
                    array(
                        'class'=>'MozProjectBundle:Currency',
                        'property'=>'code',
                        'label'=>'Devise', 'required'=>false
                    )
            )
            ->add('totalEcContrInvAmount','text',array('label'=>'Contribution CE Totale Montant IB', 'required'=>false))
            ->add('totalEcContrIbAmount','text',array('label'=>'Montant INV', 'required'=>false))
            ->add('totalEcContrInvDate','text',array('label'=>'IB Date', 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))
            ->add('totalEcContrIbDate','text',array('label'=>'INV Date ', 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))

            ->add('totalNationaleContrCentAmount','text',array('label'=>'Contribution nationale totale Centrale', 'required'=>false))
            ->add('totalNationaleContrIfiAmount','text',array('label'=>'IFI', 'required'=>false))
            ->add('totalNationaleContrRegAmount','text',array('label'=>'Regionale', 'required'=>false))

            ->add('totalNationaleContrCentDate','text',array('label'=>'Date Centrale ', 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))
            ->add('totalNationaleContrIfiDate','text',array('label'=>'Date IFI', 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))
            ->add('totalNationaleContrRegDate','text',array('label'=>'Date Regionale', 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))

            ->add('totalPrivateContrAmount','text',array('label'=>'Contribution privée totale Montant', 'required'=>false))
            ->add('totalPrivateContrDate','text',array('label'=>'Date', 'required'=>false,'attr'=>array('class'=>'datetime','onfocus'=>'doOnLoad()')))

            ->add('dibursements','collection',
                array('type'=>new ContractDibursementType(),
                    'label'=>'Decaissements du contrat',
                    'allow_add'=>true,
                    'allow_delete'=>true, 'required'=>false
                ))
           // ->add('diburGlobalCurrency')
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\Contract'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_contract';
    }
}
