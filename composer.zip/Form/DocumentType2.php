<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Moz\Moz\AdminBundle\Form\MediaSchemeType;

class DocumentType2 extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('title','text',array('label'=>'Titre', 'required'=>false))
            ->add('isLink','text',array('label_attr'=>array('style'=>'display:none'),
                'attr'=>array('style'=>'display:none', 'value'=>'1', 'required'=>false)
            ))
            ;
        $class=5;
        $builder
            ->add('type','entity',array(
                'label'=>"Type",
                'class'=>"MozProjectBundle:CategoryValues",
                'empty_value'=>"Selectionnez une Option",
                'property'=>"name",
                'required'=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                    return $r->getByClass($class);
                },
             )
            )
            ->add('description','textarea',array('label'=>'Description', 'required'=>false))
            ->add('note','textarea',array('label'=>'Note', 'required'=>false))
            ->add('uri','text',array('label'=>'Lien web', 'required'=>false))

        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\Document'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_document2';
    }
}
