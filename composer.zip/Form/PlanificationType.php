<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class PlanificationType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
		/*
            ->add('proposedStart','text',array(
                'label'=>'Date de début proposée ',
                'required'=>false,
                'attr'=>array('class'=>'datetime')

            ))
            ->add('proposedEnd','text',array(
                'label'=>'Date de fin proposée    ',
                'required'=>false,
                'attr'=>array('class'=>'datetime')
            ))
			*/
            ->add('effectiveStart','text',array(
                'label'=>'Date de début ',
                'required'=>false,
                'attr'=>array('class'=>'datetime')
            ))
            ->add('effectiveEnd','text',array(
                'label'=>'Date de fin  ',
                'required'=>false,
                'attr'=>array('class'=>'datetime')
            ))
			/*
            ->add('respectfull',null,array(
                'label'=>'Similaire à la date de début proposée',
                "required"=>false

            ))
			*/
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\Planification'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_planification';
    }
}
