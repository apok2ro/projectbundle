<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ComponentFundingType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $class= 279;
        $builder
            ->add('transactionType','entity',array(
                'label'=>"",
                'class'=>"MozProjectBundle:CategoryValues",
                'label_attr'=>array('style'=>'display:none'),
                'attr'=>array('style'=>'display:none'),
                'property'=>"name",
                'required'=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                    return $r->getById($class);
                },
            ))
            ;
             $class= 46;
            $builder
                ->add('adjustmentType','entity',array(
                        'label'=>"Type d'ajustement",
                        'class'=>"MozProjectBundle:CategoryValues",
                        'empty_value'=>"Selectionnez une Option",
                        'property'=>"name",
                        'required'=>false,
                        'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r) use ($class){
                            return $r->getByClass($class);
                        },
                    )
                )
                ->add('currency','entity',
                    array(
                        'class'=>'MozProjectBundle:Currency',
                        'property'=>'code',
                        'label'=>'Devise',
                        'required'=> false
                    )
                )
                ->add('transactionAmount','text',array('label'=>"Montant", 'attr'=>array('class'=>'datetime'),'required'=>false))
                ->add('transactionDate','text',array('label'=>"date de la transaction",
                    'attr'=>array('class'=>'datetime'), 'required'=>false))


            ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\ComponentFunding'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_componentfunding';
    }
}
