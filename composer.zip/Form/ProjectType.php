<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Moz\ProjectBundle\Form\PlanificationType;
use Moz\ProjectBundle\Form\LocalisationType;
use Moz\ProjectBundle\Form\ProjectProgramType;
use Moz\ProjectBundle\Form\ProjectProgram2Type;
use Moz\ProjectBundle\Form\ProjectProgram3Type;
use Moz\ProjectBundle\Form\ProjectCategoryValuesType;
use Moz\ProjectBundle\Form\ProjectSectorType;
use Moz\ProjectBundle\Form\ProjectSectorType2;
use Moz\ProjectBundle\Form\ProjectIssueType;
use Moz\ProjectBundle\Form\OrganisationRoleType;
use Moz\ProjectBundle\Form\OrganisationRoleType2;
use Moz\ProjectBundle\Form\OrganisationRoleType3;
use Moz\ProjectBundle\Form\OrganisationRoleType4;
use Moz\ProjectBundle\Form\OrganisationRoleType5;
use Moz\ProjectBundle\Form\OrganisationRoleType6;
use Moz\ProjectBundle\Form\OrganisationRoleType7;
use Moz\ProjectBundle\Form\FundingAmountType;
use Moz\ProjectBundle\Form\FundingBaseType;

class ProjectType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $empty= "selectionnez une option";
        $builder
            ->add('title',"textarea",array("label"=>"titre du projet","required"=>false))
           ->add('object',"textarea", array("label"=>"objectif","required"=>false))
           ->add('latitute',"text", array("label"=>"latitude","required"=>false, "attr"=>array('class'=>'map','id'=>'textlat')))
           ->add('longitude',"text", array("label"=>"longitude","required"=>false, "attr"=>array('class'=>'map','id'=>'textlon')))
           ->add('result',"textarea", array("label"=>"Résultats attendus","required"=>false))
           ->add('cost',"text", array("label"=>"Coût du projet ($)","required"=>false))
		   ->add('amount',new FundingAmountType(), array('label'=> "Coût du projet"))
            
            ->add('statuts','entity',
                array('label'=>"etat de financement",
                'class'=>'MozProjectBundle:CategoryValues',
                    'empty_value'=> "Aucun choix",
                    'property'=> 'name',
                    'expanded'=> true, 'multiple'=>false,"required"=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r){
                    return $r->getByClass(6);
                }
                ))
			
			->add('levels','entity',
                array('label'=>"Niveau d'exécution",
                'class'=>'MozProjectBundle:CategoryValues',
                    'empty_value'=> "Aucun choix",
                    'property'=> 'name',
                    'expanded'=> true, 'multiple'=>false,"required"=>false,
                'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r){
                    return $r->getByClass(57);
                }
                ))
				
			


			/*
            ->add('switch',"textarea", array("label"=>"raison du changement de statut","required"=>false))
            ->add('humanitary',null,array("label"=>"aide humanitaire","required"=>false))

            ->add('onBudget','entity',array(
                    'label'=>"Bugdet de l'activité",
                    'empty_value'=> $empty,
                    'class'=>'MozProjectBundle:CategoryValues',
                    'property'=> 'name',
                    'expanded'=> false, 'multiple'=>false,"required"=>false,
                    'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r){
                        return $r->getByClass(44);
                    }
                )
            )
			 ->add('description','textarea',array("label"=>"description","required"=>false))
            
			
            ->add('keys','collection',
                array(
                    'label'=> 'Les ids internes',
                    'type'=>new InternalIdType(),
                    'allow_add'=> true,
                    'allow_delete' => true,
                    'by_reference' => false,
                    "required"=>false
                )
            )
			*/
			
            ->add('programs','collection',array(
                    'type'=>new ProjectProgramType(),
                    'allow_add'=> true,
                    'by_reference' => false,
                    'allow_delete' => true,
                    'label_attr'=>array('style'=>"display:none;"),"required"=>false
                )
            )
			
			/*
            ->add('programs1','collection',array(
                    'type'=>new ProjectProgramType2(),
                    'allow_add'=> true,
                    'by_reference' => false,
                    'allow_delete' => true,"required"=>false
                )
            )

            ->add('programs2','collection',array(
                    'type'=>new ProjectProgramType3(),
                    'allow_add'=> true,
                    'by_reference' => false,
                    'allow_delete' => true,"required"=>false
                )
            )
			->add('sectors2','collection',array(
                    'type'=>new ProjectSectorType2(),
                    'allow_add'=> true,
                    'by_reference' => false,
                    'allow_delete' => true,
                    'label_attr'=>array('style'=>"display:none;"),"required"=>false
                )
            )

			->add('implementingAgencies','collection',array(
                    'type'=>new OrganisationRoleType3(),
                    'allow_add'=> true,
                    'allow_delete' => true,
                    'by_reference'=> false,
                    'label_attr'=>array('style'=>"display:none;"),"required"=>false
                ) )
            ->add('beneficiaryAgencies','collection',array(
                    'type'=>new OrganisationRoleType4(),
                    'allow_add'=> true,
                'by_reference'=> false,
                    'allow_delete' => true,
                'label_attr'=>array('style'=>"display:none;"),
                "required"=>false
                ) )
				*/
            ->add('contractingAgencies','collection',array(
                    'type'=>new OrganisationRoleType5(),
                    'allow_add'=> true,
                    'allow_delete' => true,
                'by_reference'=> false,
                    'label_attr'=>array('style'=>"display:none;"),"required"=>false
                ) )
				/*
            ->add('regionalGroups','collection',array(
                    'type'=>new OrganisationRoleType6(),
                    'allow_add'=> true,
                    'allow_delete' => true,
                'by_reference'=> false,
                    'label_attr'=>array('style'=>"display:none;"),"required"=>false
                ) )
            ->add('sectorialGroups','collection',array(
                    'type'=> new OrganisationRoleType7(),
                    'allow_add'=> true,
                    'allow_delete' => true,
                'by_reference'=> false,
                    'label_attr'=>array('style'=>"display:none;"),"required"=>false
                ))
				*/
            ->add('finance','collection',array(
                    'type'=>new FundingBaseType(),
                    'allow_add'=> true,
                    'allow_delete' => true,
                    'label'=>'Ligne de Financement',"required"=>false
                    //'label_attr'=>array('style'=>"display:none;"),
                )
            )
             /*
            ->add('components','collection',array(
                'type'=> new ProjectComponentType(),
                    'allow_add'=> true,
                    'allow_delete' => true,
                    'label'=>'Nouvelle Composante',"required"=>false
                )
            )
			->add('issues','collection',array(
                   'type'=> new IssueType(),
                   'allow_add'=> true,
                   'allow_delete' => true,
                   'label_attr'=>array('style'=>'display:none'),"required"=>false
               )
           )

           ->add('observations','collection',array(
                   'type'=> new RegionalObsType(),
                   'allow_add'=> true,
                   'allow_delete' => true,
                   'label_attr'=>array('style'=>'display:none'),"required"=>false
               )
           )

           ->add('econtacts','collection',array(
               'label'=>"Ajouter des Contacts Existants",
               'type'=> new ProjectContactTypee(),
               'allow_add'=> true,
               'allow_delete'=> true,"required"=>false
           ))

           ->add('contacts','collection',array(
               'label'=>"Ajouter des Nouveaux Contacts",
               'type'=> new ProjectContactType(),
               'allow_add'=> true,
               'by_reference'=> false,
               'allow_delete'=> true,"required"=>false
           ))

           ->add('contracts','collection',array(
               'label'=>"Nouveaux Contrat",
               'type'=> new ProjectContractType(),
               'allow_add'=> true,
               'allow_delete'=> true,
               'by_reference'=> false,
               "required"=>false
           ))

           ->add('indicators','collection',array(
               'label'=>"Nouvel indicateur",
               'type'=> new ProjectIndicatorType(),
               'allow_add'=> true,
               'allow_delete'=> true,"required"=>false
           ))

           ->add('sectorialobs','collection',array(
                   'type'=> new RegionalObsType2(),
                   'allow_add'=> true,
                   'allow_delete' => true,
                   'label'=>'Nouvelles observations',"required"=>false
               )
           )

           ->add('documents','collection',array(
                   'type'=> new ProjectDocumentType(),
                   'allow_add'=> true,
                   'allow_delete' => true,
                   'label'=>'Documents',"required"=>false
               )
           )

           ->add('links','collection',array(
                   'type'=> new ProjectDocumentType2(),
                   'allow_add'=> true,
                   'allow_delete' => true,
                   'label'=>'Liens',"required"=>false
               )
           )
        */


        
			
			
			
			
			
			
			
			
			
			
			

            ->add('fundingSource','entity',array(
                'label'=>"sources de financement",
                    'class'=>'MozProjectBundle:CategoryValues',
                    'property'=> 'name',
                    'expanded'=> true, 'multiple'=>true,"required"=>false,
                    'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r){
                        return $r->getByClass(15);
                    }
                )
            )



            //->add('planification', new PlanificationType(), array('label'=>'Durée du projet'))
            ->add('startdate', 'text', array('label'=>'Date de debut','required'=>false,
                'attr'=>array('class'=>'datetime')))
            ->add('enddate', 'text', array('label'=>'Date de fin','required'=>false,
                'attr'=>array('class'=>'datetime')))
            ->add('locations','collection',array(
                'type'=>new LocalisationType(),
                    'allow_add'=> true,
                    'allow_delete' => true,
                    'by_reference' => false,
                    "required"=>false,
                    'by_reference' => false,
                 )
            )

            ->add('implementation','entity',array(
                'label'=>"envergure",
                    'class'=>'MozProjectBundle:CategoryValues',
                    'property'=> 'name',
                    'expanded'=> true, 'multiple'=>false,"required"=>false,
                    'query_builder'=>function(\Moz\ProjectBundle\Entity\CategoryValuesRepository $r){
                        return $r->getByClass(7);
                    }
                )
            )

            ->add('sectors','collection',array(
                    'type'=>new ProjectSectorType(),
                    'allow_add'=> true,
                    'by_reference' => false,
                    'allow_delete' => true,
                    'label_attr'=>array('style'=>"display:none;"),"required"=>false
                )
            )
            

            ->add('opportunite','textarea', array('label'=>'Bénéficiaires directs',"required"=>false))
            ->add('environnement', 'textarea', array('label'=>'Impact Environnemental',"required"=>false))
            ->add('emploi','textarea', array('label'=>'Emploi Homme',"required"=>false))
            ->add('emploif','textarea', array('label'=>'Emploi Femme',"required"=>false))
            ->add('comp','textarea', array('label'=>'Composantes',"required"=>false))
            ->add('obs','textarea', array('label'=>'Observations',"required"=>false))

            ->add('mins','collection',array(
                'type'=> new OrganisationRoleType(),
                'allow_add'=> true,
                'allow_delete' => true,
                'by_reference'=> false,
                'label_attr'=>array('style'=>"display:none;"),"required"=>false
            ))

            //*
            ->add('executionAgencies','collection',array(
                    'type'=> new OrganisationRoleType2(),
                    'allow_add'=> true,
                    'allow_delete' => true,
                    'by_reference'=> false,
                    'label_attr'=>array('style'=>"display:none;"),"required"=>false
                ))
            //*/

            
           


        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\Project'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_project';
    }
}
