<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class InternalIdType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('group','entity',
                array(
                    "label"=>"selctionner le groupe d'organisation",
                "class"=>"MozProjectBundle:OrganisationGroup",
                "property"=>"name",
                    "attr"=>array('onchange'=>'getOrgByGroup(this)')
                )
            )
            ->add('organisation','entity',
                array(
                    "label"=>"spécifier l'organisation",
                    "class"=>"MozProjectBundle:Organisation",
                    "property"=>"organisation"
                )
            )
            ->add('value','text',array('label'=>"Entrer l'Id"))
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\InternalId'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_internalid';
    }
}
