<?php

namespace Moz\ProjectBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Moz\ProjectBundle\Form\PlanificationType;
use Moz\ProjectBundle\Form\LocalisationType;
use Moz\ProjectBundle\Form\ProjectProgramType;
use Moz\ProjectBundle\Form\ProjectProgram2Type;
use Moz\ProjectBundle\Form\ProjectProgram3Type;
use Moz\ProjectBundle\Form\ProjectCategoryValuesType;
use Moz\ProjectBundle\Form\ProjectSectorType;
use Moz\ProjectBundle\Form\ProjectSectorType2;
use Moz\ProjectBundle\Form\ProjectIssueType;
use Moz\ProjectBundle\Form\OrganisationRoleType;
use Moz\ProjectBundle\Form\OrganisationRoleType2;
use Moz\ProjectBundle\Form\OrganisationRoleType3;
use Moz\ProjectBundle\Form\OrganisationRoleType4;
use Moz\ProjectBundle\Form\OrganisationRoleType5;
use Moz\ProjectBundle\Form\OrganisationRoleType6;
use Moz\ProjectBundle\Form\OrganisationRoleType7;
use Moz\ProjectBundle\Form\FundingAmountType;
use Moz\ProjectBundle\Form\FundingBaseType;

class ProjectFactFilter1Type extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {

        $builder
            ->add('title',"text",array("label"=>"Entrez un mot clef"
            ,"label_attr"=>array("style"=>"display:non;"),
                "required"=>false))




        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Moz\ProjectBundle\Entity\Project'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'moz_projectbundle_projectfactfilter1';
    }
}
