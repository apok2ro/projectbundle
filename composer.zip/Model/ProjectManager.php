<?php 
namespace Moz\ProjectBundle\Model;

use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Security\Core\SecurityContext;
use \Doctrine\Bundle\DoctrineBundle\Registry;
use Gero\ForumBundle\Entity\Post;
use Gero\ForumBundle\Entity\Zpost;
use Gero\ForumBundle\Entity\Tpost;
use Gero\ForumBundle\Entity\Postable;
use Gero\ForumBundle\Entity\Theme;
use Gero\ForumBundle\Entity\Cercle;
use Gero\ForumBundle\Entity\Demande;
use Gero\UserBundle\Entity\User;
use Doctrine\ORM\Tools\Pagination\Paginator;
use Moz\Moz\AdminBundle\Entity\Zone;
use Moz\Moz\AdminBundle\Entity\MediaScheme;
use Moz\Moz\AdminBundle\Form\MediaSchemeType;
use Moz\Moz\AdminBundle\Entity\MenuScheme;
use Moz\Moz\AdminBundle\Entity\WidgetScheme;
use Moz\Moz\AdminBundle\Entity\TextScheme;

/**
* 
*/
class ProjectManager extends \Twig_Extension
{	

	private $em;
	private $sec;


	function __construct(Registry $doc, SecurityContext $sci)
	{
		$this->em = $doc->getManager();
		$this->sec = $sci;
	}



	public function getOrgByGroup($g){
		//$zp = $this->em->getRepository('MozProjectBundle:Organisation');
		//$nodes= $zp->findBy(array('group'=>$g), array('organisation'=>'desc'),null);
		//return $nodes;

		$qb = $this->em->createQueryBuilder();
		$qb->select('o.id')
			->from("MozProjectBundle:Organisation","o")
			->Where('o.group = :g')->setParameter("g",$g);
		$query= $qb->getQuery();
		return $query->getResult();

	}


	public function getName()
	{
		return "project_manager";
	}

	public function persist($elem){
		$this->em->persist($elem);
		$this->em->flush();
		return $elem;
	}
}